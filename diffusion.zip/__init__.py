"""
Stanford Dogs Diffusion - 扩散过程模块

包含噪声调度器、DDPM/DDIM 采样器和高斯扩散模型
"""

from .scheduler import (
    linear_beta_schedule,
    cosine_beta_schedule,
    quadratic_beta_schedule,
    sigmoid_beta_schedule,
    NoiseScheduler,
    DDPMScheduler,
)

from .ddim import (
    DDIMScheduler,
    DDIMInversion,
    make_ddim_timesteps,
)

from .gaussian_diffusion import (
    GaussianDiffusion,
    EMA,
)

from .losses import (
    SSIMLoss,
    MultiScaleSSIMLoss,
    PerceptualLoss,
    FrequencyLoss,
    EdgeLoss,
    CombinedDiffusionLoss,
    VelocityPredictionLoss,
    MinSNRWeighting,
)


__all__ = [
    # Beta schedules
    "linear_beta_schedule",
    "cosine_beta_schedule",
    "quadratic_beta_schedule",
    "sigmoid_beta_schedule",
    # Schedulers
    "NoiseScheduler",
    "DDPMScheduler",
    "DDIMScheduler",
    # DDIM
    "DDIMInversion",
    "make_ddim_timesteps",
    # Diffusion
    "GaussianDiffusion",
    "EMA",
    # Losses
    "SSIMLoss",
    "MultiScaleSSIMLoss",
    "PerceptualLoss",
    "FrequencyLoss",
    "EdgeLoss",
    "CombinedDiffusionLoss",
    "VelocityPredictionLoss",
    "MinSNRWeighting",
]
