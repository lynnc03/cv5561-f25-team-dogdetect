"""
高斯扩散模型

整合前向扩散、反向扩散和损失计算的完整扩散模型
"""
from typing import Dict, Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import tqdm

from .scheduler import NoiseScheduler, DDPMScheduler
from .losses import CombinedDiffusionLoss, MinSNRWeighting


class GaussianDiffusion(nn.Module):
    """
    高斯扩散模型

    整合 DDPM 的训练和采样过程
    """

    def __init__(
        self,
        model: nn.Module,
        num_timesteps: int = 1000,
        beta_start: float = 1e-4,
        beta_end: float = 0.02,
        beta_schedule: str = "linear",
        loss_type: str = "l2",
        prediction_type: str = "epsilon",
        clip_sample: bool = True,
        device: str = "cpu",
    ):
        """
        参数:
            model: UNet 噪声预测模型
            num_timesteps: 扩散时间步数
            beta_start: 起始 beta
            beta_end: 结束 beta
            beta_schedule: 噪声调度类型
            loss_type: 损失函数类型 ("l1", "l2", "huber")
            prediction_type: 预测类型 ("epsilon", "x_start", "v_prediction")
            clip_sample: 是否裁剪采样
            device: 设备
        """
        super().__init__()

        self.model = model
        self.num_timesteps = num_timesteps
        self.loss_type = loss_type
        self.prediction_type = prediction_type
        self.clip_sample = clip_sample
        self.device = device

        # 创建调度器
        self.scheduler = DDPMScheduler(
            num_timesteps=num_timesteps,
            beta_start=beta_start,
            beta_end=beta_end,
            beta_schedule=beta_schedule,
            device=device,
        )

    def to(self, device: str):
        """移动到指定设备"""
        self.device = device
        self.model = self.model.to(device)
        self.scheduler.to(device)
        return self

    def q_sample(
        self,
        x_start: torch.Tensor,
        t: torch.Tensor,
        noise: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        前向扩散过程: q(x_t | x_0)

        参数:
            x_start: 原始图像
            t: 时间步
            noise: 噪声 (可选)

        返回:
            加噪后的图像
        """
        return self.scheduler.q_sample(x_start, t, noise)

    def predict_start_from_noise(
        self,
        x_t: torch.Tensor,
        t: torch.Tensor,
        noise: torch.Tensor,
    ) -> torch.Tensor:
        """从噪声预测 x_0"""
        return self.scheduler.predict_start_from_noise(x_t, t, noise)

    def get_v_prediction(
        self,
        x_start: torch.Tensor,
        noise: torch.Tensor,
        t: torch.Tensor,
    ) -> torch.Tensor:
        """
        计算 v-prediction 目标

        v = sqrt(alpha_bar) * noise - sqrt(1-alpha_bar) * x_0

        参数:
            x_start: 原始图像
            noise: 噪声
            t: 时间步

        返回:
            v-prediction 目标
        """
        sqrt_alphas_cumprod = self.scheduler._extract(
            self.scheduler.sqrt_alphas_cumprod, t, x_start.shape
        )
        sqrt_one_minus_alphas_cumprod = self.scheduler._extract(
            self.scheduler.sqrt_one_minus_alphas_cumprod, t, x_start.shape
        )
        return sqrt_alphas_cumprod * noise - sqrt_one_minus_alphas_cumprod * x_start

    def training_losses(
        self,
        x_start: torch.Tensor,
        t: torch.Tensor,
        y: torch.Tensor = None,
        noise: torch.Tensor = None,
    ) -> Dict[str, torch.Tensor]:
        """
        计算训练损失

        参数:
            x_start: 原始图像
            t: 时间步
            y: 类别标签 (可选)
            noise: 噪声 (可选)

        返回:
            包含损失的字典
        """
        if noise is None:
            noise = torch.randn_like(x_start)

        # 前向扩散
        x_t = self.q_sample(x_start, t, noise)

        # 模型预测
        model_output = self.model(x_t, t, y)

        # 确定目标
        if self.prediction_type == "epsilon":
            target = noise
        elif self.prediction_type == "x_start":
            target = x_start
        elif self.prediction_type == "v_prediction":
            target = self.get_v_prediction(x_start, noise, t)
        else:
            raise ValueError(f"Unknown prediction type: {self.prediction_type}")

        # 计算损失
        if self.loss_type == "l1":
            loss = F.l1_loss(model_output, target, reduction="none")
        elif self.loss_type == "l2":
            loss = F.mse_loss(model_output, target, reduction="none")
        elif self.loss_type == "huber":
            loss = F.smooth_l1_loss(model_output, target, reduction="none")
        else:
            raise ValueError(f"Unknown loss type: {self.loss_type}")

        # 求平均
        loss = loss.mean()

        return {
            "loss": loss,
            "x_t": x_t,
            "model_output": model_output,
            "target": target,
        }

    def training_losses_with_snr_weighting(
        self,
        x_start: torch.Tensor,
        t: torch.Tensor,
        y: torch.Tensor = None,
        noise: torch.Tensor = None,
        snr_gamma: float = 5.0,
    ) -> Dict[str, torch.Tensor]:
        """
        使用 SNR 加权的训练损失

        来自 "Scalable Diffusion Models with State Space Backbone" 论文

        参数:
            x_start: 原始图像
            t: 时间步
            y: 类别标签
            noise: 噪声
            snr_gamma: SNR 加权参数

        返回:
            包含损失的字典
        """
        if noise is None:
            noise = torch.randn_like(x_start)

        # 前向扩散
        x_t = self.q_sample(x_start, t, noise)

        # 模型预测
        model_output = self.model(x_t, t, y)

        # 确定目标
        if self.prediction_type == "epsilon":
            target = noise
        elif self.prediction_type == "x_start":
            target = x_start
        elif self.prediction_type == "v_prediction":
            target = self.get_v_prediction(x_start, noise, t)
        else:
            raise ValueError(f"Unknown prediction type: {self.prediction_type}")

        # 计算损失
        if self.loss_type == "l2":
            loss = F.mse_loss(model_output, target, reduction="none")
        else:
            loss = F.l1_loss(model_output, target, reduction="none")

        # SNR 加权
        snr = self.scheduler.get_snr(t)
        snr_weight = torch.clamp(snr, max=snr_gamma) / snr_gamma

        # 应用权重
        loss = loss.mean(dim=[1, 2, 3]) * snr_weight
        loss = loss.mean()

        return {
            "loss": loss,
            "x_t": x_t,
            "model_output": model_output,
            "target": target,
        }

    def training_losses_with_visual(
        self,
        x_start: torch.Tensor,
        t: torch.Tensor,
        y: torch.Tensor = None,
        noise: torch.Tensor = None,
        visual_loss_fn: CombinedDiffusionLoss = None,
        snr_gamma: float = 5.0,
        use_snr_weighting: bool = True,
    ) -> Dict[str, torch.Tensor]:
        """
        带视觉损失的训练损失计算

        参数:
            x_start: 原始图像
            t: 时间步
            y: 类别标签
            noise: 噪声
            visual_loss_fn: 视觉损失函数 (CombinedDiffusionLoss)
            snr_gamma: SNR加权参数
            use_snr_weighting: 是否使用SNR加权

        返回:
            包含损失的字典
        """
        if noise is None:
            noise = torch.randn_like(x_start)

        # 前向扩散
        x_t = self.q_sample(x_start, t, noise)

        # 模型预测
        model_output = self.model(x_t, t, y)

        # 确定目标和预测的x_0
        if self.prediction_type == "epsilon":
            target = noise
            # 从预测的噪声恢复x_0
            pred_x_start = self.predict_start_from_noise(x_t, t, model_output)
        elif self.prediction_type == "x_start":
            target = x_start
            pred_x_start = model_output
        elif self.prediction_type == "v_prediction":
            target = self.get_v_prediction(x_start, noise, t)
            # 从v预测恢复x_0
            sqrt_alphas_cumprod = self.scheduler._extract(
                self.scheduler.sqrt_alphas_cumprod, t, x_t.shape
            )
            sqrt_one_minus_alphas_cumprod = self.scheduler._extract(
                self.scheduler.sqrt_one_minus_alphas_cumprod, t, x_t.shape
            )
            pred_x_start = sqrt_alphas_cumprod * x_t - sqrt_one_minus_alphas_cumprod * model_output
        else:
            raise ValueError(f"Unknown prediction type: {self.prediction_type}")

        # 裁剪预测的x_0到有效范围
        pred_x_start = torch.clamp(pred_x_start, -1.0, 1.0)

        # 计算基础损失
        if self.loss_type == "l2":
            base_loss = F.mse_loss(model_output, target, reduction="none")
        elif self.loss_type == "l1":
            base_loss = F.l1_loss(model_output, target, reduction="none")
        else:
            base_loss = F.smooth_l1_loss(model_output, target, reduction="none")

        # SNR加权
        if use_snr_weighting:
            snr = self.scheduler.get_snr(t)
            snr_weight = torch.clamp(snr, max=snr_gamma) / snr_gamma
            base_loss = base_loss.mean(dim=[1, 2, 3]) * snr_weight
            base_loss = base_loss.mean()
        else:
            base_loss = base_loss.mean()

        # 计算视觉损失 (只在低噪声时间步添加，高噪声时x_0预测不准确)
        visual_loss = torch.tensor(0.0, device=x_start.device)
        loss_dict = {"base_loss": base_loss.item()}

        if visual_loss_fn is not None:
            # 只在较低的时间步 (t < 500) 计算视觉损失
            # 因为高噪声时间步的x_0预测非常不准确
            low_noise_mask = (t < self.num_timesteps // 2).float()

            if low_noise_mask.sum() > 0:
                # 选择低噪声样本
                total_loss, visual_loss_dict = visual_loss_fn(
                    model_output=model_output,
                    target=target,
                    x_start=x_start,
                    pred_x_start=pred_x_start,
                )
                # 减去base_loss因为visual_loss_fn已经计算了
                visual_loss = (total_loss - base_loss) * low_noise_mask.mean()
                loss_dict.update({f"visual_{k}": v for k, v in visual_loss_dict.items()})

        total_loss = base_loss + visual_loss
        loss_dict["total_loss"] = total_loss.item()
        loss_dict["visual_loss"] = visual_loss.item() if isinstance(visual_loss, torch.Tensor) else visual_loss

        return {
            "loss": total_loss,
            "base_loss": base_loss,
            "visual_loss": visual_loss,
            "x_t": x_t,
            "model_output": model_output,
            "target": target,
            "pred_x_start": pred_x_start,
            "loss_dict": loss_dict,
        }

    @torch.no_grad()
    def p_sample(
        self,
        x_t: torch.Tensor,
        t: torch.Tensor,
        y: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        单步采样: p(x_{t-1} | x_t)

        参数:
            x_t: 当前图像
            t: 时间步
            y: 类别标签

        返回:
            x_{t-1}
        """
        return self.scheduler.p_sample(
            model=self.model,
            x_t=x_t,
            t=t,
            y=y,
            clip_denoised=self.clip_sample,
            prediction_type=self.prediction_type,
        )

    @torch.no_grad()
    def sample(
        self,
        batch_size: int,
        image_size: int,
        channels: int = 3,
        y: torch.Tensor = None,
        return_intermediates: bool = False,
        show_progress: bool = True,
    ) -> Union[torch.Tensor, Tuple[torch.Tensor, list]]:
        """
        完整采样过程

        参数:
            batch_size: 批次大小
            image_size: 图像大小
            channels: 通道数
            y: 类别标签
            return_intermediates: 是否返回中间结果
            show_progress: 是否显示进度

        返回:
            生成的图像
        """
        shape = (batch_size, channels, image_size, image_size)

        # 从纯噪声开始
        x = torch.randn(shape, device=self.device)

        intermediates = []

        # 反向扩散
        timesteps = range(self.num_timesteps - 1, -1, -1)
        if show_progress:
            timesteps = tqdm(timesteps, desc="Sampling", mininterval=5, ncols=80)

        for t in timesteps:
            t_batch = torch.full((batch_size,), t, device=self.device, dtype=torch.long)
            x = self.p_sample(x, t_batch, y)

            if return_intermediates:
                intermediates.append(x.clone())

        if return_intermediates:
            return x, intermediates

        return x

    @torch.no_grad()
    def sample_with_cfg(
        self,
        batch_size: int,
        image_size: int,
        y: torch.Tensor,
        guidance_scale: float = 7.5,
        channels: int = 3,
        show_progress: bool = True,
    ) -> torch.Tensor:
        """
        使用 Classifier-Free Guidance 采样

        参数:
            batch_size: 批次大小
            image_size: 图像大小
            y: 类别标签
            guidance_scale: CFG 强度
            channels: 通道数
            show_progress: 是否显示进度

        返回:
            生成的图像
        """
        shape = (batch_size, channels, image_size, image_size)

        # 从纯噪声开始
        x = torch.randn(shape, device=self.device)

        # 反向扩散
        timesteps = range(self.num_timesteps - 1, -1, -1)
        if show_progress:
            timesteps = tqdm(timesteps, desc="Sampling with CFG", mininterval=5, ncols=80)

        for t in timesteps:
            t_batch = torch.full((batch_size,), t, device=self.device, dtype=torch.long)

            # 有条件预测
            noise_pred_cond = self.model(x, t_batch, y)

            # 无条件预测
            noise_pred_uncond = self.model(x, t_batch, None)

            # CFG 组合
            noise_pred = noise_pred_uncond + guidance_scale * (noise_pred_cond - noise_pred_uncond)

            # 使用组合后的预测进行采样
            model_mean, _, model_log_variance = self.scheduler.p_mean_variance(
                model_output=noise_pred,
                x_t=x,
                t=t_batch,
                clip_denoised=self.clip_sample,
                prediction_type=self.prediction_type,
            )

            # 添加噪声
            noise = torch.randn_like(x)
            nonzero_mask = (t_batch != 0).float().view(-1, *([1] * (len(x.shape) - 1)))
            x = model_mean + nonzero_mask * torch.exp(0.5 * model_log_variance) * noise

        return x

    def forward(
        self,
        x: torch.Tensor,
        y: torch.Tensor = None,
    ) -> Dict[str, torch.Tensor]:
        """
        训练前向传播

        参数:
            x: 输入图像
            y: 类别标签

        返回:
            包含损失的字典
        """
        # 随机采样时间步
        t = torch.randint(0, self.num_timesteps, (x.shape[0],), device=self.device)

        return self.training_losses(x, t, y)


class EMA:
    """
    指数移动平均

    用于稳定训练和提高生成质量
    """

    def __init__(
        self,
        model: nn.Module,
        decay: float = 0.9999,
        update_after_step: int = 0,
        update_every: int = 10,
    ):
        """
        参数:
            model: 原始模型
            decay: 衰减率
            update_after_step: 开始更新的步数
            update_every: 更新间隔
        """
        self.model = model
        self.decay = decay
        self.update_after_step = update_after_step
        self.update_every = update_every

        # 创建 EMA 模型副本
        self.ema_model = self._create_ema_model()
        self.ema_model.eval()

        self.step = 0

    def _create_ema_model(self) -> nn.Module:
        """创建 EMA 模型副本"""
        import copy
        ema_model = copy.deepcopy(self.model)
        for param in ema_model.parameters():
            param.requires_grad_(False)
        return ema_model

    @torch.no_grad()
    def update(self):
        """更新 EMA 权重"""
        self.step += 1

        if self.step <= self.update_after_step:
            return

        if self.step % self.update_every != 0:
            return

        for ema_param, model_param in zip(
            self.ema_model.parameters(), self.model.parameters()
        ):
            ema_param.data.mul_(self.decay).add_(model_param.data, alpha=1 - self.decay)

    def get_ema_model(self) -> nn.Module:
        """获取 EMA 模型"""
        return self.ema_model

    def state_dict(self) -> dict:
        """获取状态字典"""
        return {
            "step": self.step,
            "ema_model": self.ema_model.state_dict(),
        }

    def load_state_dict(self, state_dict: dict):
        """加载状态字典"""
        self.step = state_dict["step"]
        self.ema_model.load_state_dict(state_dict["ema_model"])


if __name__ == "__main__":
    # 测试代码
    import sys
    sys.path.append("/users/5/chen9005/FFF/dogs_diff")

    from models import UNetModelSmall

    print("=" * 60)
    print("高斯扩散模型测试")
    print("=" * 60)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"使用设备: {device}")

    # 创建小型 UNet 模型
    model = UNetModelSmall(image_size=64, num_classes=120).to(device)

    # 创建扩散模型
    diffusion = GaussianDiffusion(
        model=model,
        num_timesteps=1000,
        beta_schedule="cosine",
        loss_type="l2",
        prediction_type="epsilon",
        device=device,
    )

    print("\n" + "-" * 40)
    print("测试训练损失计算")
    print("-" * 40)

    # 创建假数据
    batch_size = 4
    x = torch.randn(batch_size, 3, 64, 64, device=device)
    y = torch.randint(0, 120, (batch_size,), device=device)
    t = torch.randint(0, 1000, (batch_size,), device=device)

    # 计算损失
    loss_dict = diffusion.training_losses(x, t, y)
    print(f"损失: {loss_dict['loss'].item():.4f}")
    print(f"x_t 形状: {loss_dict['x_t'].shape}")
    print(f"模型输出形状: {loss_dict['model_output'].shape}")

    print("\n" + "-" * 40)
    print("测试 SNR 加权损失")
    print("-" * 40)

    loss_dict_snr = diffusion.training_losses_with_snr_weighting(x, t, y)
    print(f"SNR 加权损失: {loss_dict_snr['loss'].item():.4f}")

    print("\n" + "-" * 40)
    print("测试 EMA")
    print("-" * 40)

    ema = EMA(model, decay=0.9999, update_every=10)
    for _ in range(100):
        ema.update()
    print(f"EMA 步数: {ema.step}")

    print("\n测试完成!")
