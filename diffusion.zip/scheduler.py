"""
噪声调度器 - 定义扩散过程的噪声水平

实现多种噪声调度策略:
- Linear: 线性调度
- Cosine: 余弦调度 (更平滑)
- Quadratic: 二次调度
"""
import math
from typing import Tuple, Optional

import torch
import torch.nn as nn
import numpy as np


def linear_beta_schedule(
    timesteps: int,
    beta_start: float = 1e-4,
    beta_end: float = 0.02,
) -> torch.Tensor:
    """
    线性噪声调度

    参数:
        timesteps: 总时间步数
        beta_start: 起始 beta 值
        beta_end: 结束 beta 值

    返回:
        beta 序列 [timesteps]
    """
    return torch.linspace(beta_start, beta_end, timesteps)


def cosine_beta_schedule(
    timesteps: int,
    s: float = 0.008,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    余弦噪声调度

    来自 "Improved Denoising Diffusion Probabilistic Models" 论文
    产生更平滑的噪声衰减曲线

    参数:
        timesteps: 总时间步数
        s: 偏移量

    返回:
        (betas, alphas_cumprod) - 同时返回 betas 和 alphas_cumprod 以避免 off-by-one 错误
    """
    steps = timesteps + 1
    x = torch.linspace(0, timesteps, steps)

    # 计算 alpha_bar (1001 个点)
    alphas_cumprod_full = torch.cos(((x / timesteps) + s) / (1 + s) * math.pi * 0.5) ** 2
    alphas_cumprod_full = alphas_cumprod_full / alphas_cumprod_full[0]

    # 取前 timesteps 个作为 alphas_cumprod (索引 0 到 999)
    alphas_cumprod = alphas_cumprod_full[:timesteps]

    # 从 alphas_cumprod 计算 betas
    alphas_cumprod_prev = torch.cat([torch.tensor([1.0]), alphas_cumprod[:-1]])
    betas = 1 - alphas_cumprod / alphas_cumprod_prev
    betas = torch.clip(betas, 0.0001, 0.9999)

    return betas, alphas_cumprod


def quadratic_beta_schedule(
    timesteps: int,
    beta_start: float = 1e-4,
    beta_end: float = 0.02,
) -> torch.Tensor:
    """
    二次噪声调度

    参数:
        timesteps: 总时间步数
        beta_start: 起始 beta 值
        beta_end: 结束 beta 值

    返回:
        beta 序列 [timesteps]
    """
    return torch.linspace(beta_start ** 0.5, beta_end ** 0.5, timesteps) ** 2


def sigmoid_beta_schedule(
    timesteps: int,
    beta_start: float = 1e-4,
    beta_end: float = 0.02,
) -> torch.Tensor:
    """
    Sigmoid 噪声调度

    参数:
        timesteps: 总时间步数
        beta_start: 起始 beta 值
        beta_end: 结束 beta 值

    返回:
        beta 序列 [timesteps]
    """
    betas = torch.linspace(-6, 6, timesteps)
    return torch.sigmoid(betas) * (beta_end - beta_start) + beta_start


class NoiseScheduler:
    """
    噪声调度器

    管理扩散过程中的噪声水平和相关参数
    """

    def __init__(
        self,
        num_timesteps: int = 1000,
        beta_start: float = 1e-4,
        beta_end: float = 0.02,
        beta_schedule: str = "linear",
        device: str = "cpu",
    ):
        """
        参数:
            num_timesteps: 总时间步数
            beta_start: 起始 beta 值
            beta_end: 结束 beta 值
            beta_schedule: 调度类型 ("linear", "cosine", "quadratic", "sigmoid")
            device: 设备
        """
        self.num_timesteps = num_timesteps
        self.beta_start = beta_start
        self.beta_end = beta_end
        self.beta_schedule = beta_schedule
        self.device = device

        # 计算 beta 序列和 alpha 相关参数
        if beta_schedule == "linear":
            self.betas = linear_beta_schedule(num_timesteps, beta_start, beta_end)
            self.alphas = 1.0 - self.betas
            self.alphas_cumprod = torch.cumprod(self.alphas, dim=0)
        elif beta_schedule == "cosine":
            # cosine schedule 直接返回正确的 alphas_cumprod，避免 off-by-one 错误
            self.betas, self.alphas_cumprod = cosine_beta_schedule(num_timesteps)
            self.alphas = 1.0 - self.betas
        elif beta_schedule == "quadratic":
            self.betas = quadratic_beta_schedule(num_timesteps, beta_start, beta_end)
            self.alphas = 1.0 - self.betas
            self.alphas_cumprod = torch.cumprod(self.alphas, dim=0)
        elif beta_schedule == "sigmoid":
            self.betas = sigmoid_beta_schedule(num_timesteps, beta_start, beta_end)
            self.alphas = 1.0 - self.betas
            self.alphas_cumprod = torch.cumprod(self.alphas, dim=0)
        else:
            raise ValueError(f"Unknown beta schedule: {beta_schedule}")

        self.alphas_cumprod_prev = torch.cat([torch.tensor([1.0]), self.alphas_cumprod[:-1]])

        # 预计算常用值
        self.sqrt_alphas_cumprod = torch.sqrt(self.alphas_cumprod)
        self.sqrt_one_minus_alphas_cumprod = torch.sqrt(1.0 - self.alphas_cumprod)

        # 用于 q(x_{t-1} | x_t, x_0) 的计算
        self.sqrt_recip_alphas = torch.sqrt(1.0 / self.alphas)
        self.sqrt_recip_alphas_cumprod = torch.sqrt(1.0 / self.alphas_cumprod)
        self.sqrt_recipm1_alphas_cumprod = torch.sqrt(1.0 / self.alphas_cumprod - 1)

        # 后验分布参数
        self.posterior_variance = (
            self.betas * (1.0 - self.alphas_cumprod_prev) / (1.0 - self.alphas_cumprod)
        )
        self.posterior_log_variance_clipped = torch.log(
            torch.cat([self.posterior_variance[1:2], self.posterior_variance[1:]])
        )
        self.posterior_mean_coef1 = (
            self.betas * torch.sqrt(self.alphas_cumprod_prev) / (1.0 - self.alphas_cumprod)
        )
        self.posterior_mean_coef2 = (
            (1.0 - self.alphas_cumprod_prev) * torch.sqrt(self.alphas) / (1.0 - self.alphas_cumprod)
        )

        # 移动到指定设备
        self.to(device)

    def to(self, device: str):
        """移动所有张量到指定设备"""
        self.device = device
        self.betas = self.betas.to(device)
        self.alphas = self.alphas.to(device)
        self.alphas_cumprod = self.alphas_cumprod.to(device)
        self.alphas_cumprod_prev = self.alphas_cumprod_prev.to(device)
        self.sqrt_alphas_cumprod = self.sqrt_alphas_cumprod.to(device)
        self.sqrt_one_minus_alphas_cumprod = self.sqrt_one_minus_alphas_cumprod.to(device)
        self.sqrt_recip_alphas = self.sqrt_recip_alphas.to(device)
        self.sqrt_recip_alphas_cumprod = self.sqrt_recip_alphas_cumprod.to(device)
        self.sqrt_recipm1_alphas_cumprod = self.sqrt_recipm1_alphas_cumprod.to(device)
        self.posterior_variance = self.posterior_variance.to(device)
        self.posterior_log_variance_clipped = self.posterior_log_variance_clipped.to(device)
        self.posterior_mean_coef1 = self.posterior_mean_coef1.to(device)
        self.posterior_mean_coef2 = self.posterior_mean_coef2.to(device)
        return self

    def _extract(self, a: torch.Tensor, t: torch.Tensor, x_shape: Tuple) -> torch.Tensor:
        """
        从预计算的序列中提取指定时间步的值

        参数:
            a: 预计算的序列
            t: 时间步索引 [batch_size]
            x_shape: 目标形状 (用于广播)

        返回:
            提取的值，形状为 [batch_size, 1, 1, 1]
        """
        batch_size = t.shape[0]
        out = a.gather(-1, t)
        return out.reshape(batch_size, *((1,) * (len(x_shape) - 1)))

    def q_sample(
        self,
        x_start: torch.Tensor,
        t: torch.Tensor,
        noise: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        前向扩散过程: q(x_t | x_0)

        给定原始图像 x_0 和时间步 t，采样 x_t

        参数:
            x_start: 原始图像 [batch, channels, height, width]
            t: 时间步 [batch]
            noise: 噪声 (如果为 None 则随机生成)

        返回:
            加噪后的图像 x_t
        """
        if noise is None:
            noise = torch.randn_like(x_start)

        sqrt_alphas_cumprod_t = self._extract(self.sqrt_alphas_cumprod, t, x_start.shape)
        sqrt_one_minus_alphas_cumprod_t = self._extract(
            self.sqrt_one_minus_alphas_cumprod, t, x_start.shape
        )

        # x_t = sqrt(alpha_bar_t) * x_0 + sqrt(1 - alpha_bar_t) * noise
        return sqrt_alphas_cumprod_t * x_start + sqrt_one_minus_alphas_cumprod_t * noise

    def q_posterior_mean_variance(
        self,
        x_start: torch.Tensor,
        x_t: torch.Tensor,
        t: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        计算后验分布 q(x_{t-1} | x_t, x_0) 的均值和方差

        参数:
            x_start: 原始图像 x_0
            x_t: 当前时间步的图像
            t: 时间步

        返回:
            (后验均值, 后验方差, 后验对数方差)
        """
        posterior_mean = (
            self._extract(self.posterior_mean_coef1, t, x_t.shape) * x_start
            + self._extract(self.posterior_mean_coef2, t, x_t.shape) * x_t
        )
        posterior_variance = self._extract(self.posterior_variance, t, x_t.shape)
        posterior_log_variance_clipped = self._extract(
            self.posterior_log_variance_clipped, t, x_t.shape
        )
        return posterior_mean, posterior_variance, posterior_log_variance_clipped

    def predict_start_from_noise(
        self,
        x_t: torch.Tensor,
        t: torch.Tensor,
        noise: torch.Tensor,
    ) -> torch.Tensor:
        """
        从噪声预测原始图像 x_0

        参数:
            x_t: 当前时间步的图像
            t: 时间步
            noise: 预测的噪声

        返回:
            预测的原始图像 x_0
        """
        return (
            self._extract(self.sqrt_recip_alphas_cumprod, t, x_t.shape) * x_t
            - self._extract(self.sqrt_recipm1_alphas_cumprod, t, x_t.shape) * noise
        )

    def predict_noise_from_start(
        self,
        x_t: torch.Tensor,
        t: torch.Tensor,
        x_start: torch.Tensor,
    ) -> torch.Tensor:
        """
        从原始图像预测噪声

        参数:
            x_t: 当前时间步的图像
            t: 时间步
            x_start: 原始图像 x_0

        返回:
            预测的噪声
        """
        return (
            self._extract(self.sqrt_recip_alphas_cumprod, t, x_t.shape) * x_t - x_start
        ) / self._extract(self.sqrt_recipm1_alphas_cumprod, t, x_t.shape)

    def get_snr(self, t: torch.Tensor) -> torch.Tensor:
        """
        计算信噪比 (Signal-to-Noise Ratio)

        参数:
            t: 时间步

        返回:
            SNR 值
        """
        return self.alphas_cumprod[t] / (1 - self.alphas_cumprod[t])


class DDPMScheduler(NoiseScheduler):
    """
    DDPM 调度器

    实现 DDPM 论文中的采样过程
    """

    def p_mean_variance(
        self,
        model_output: torch.Tensor,
        x_t: torch.Tensor,
        t: torch.Tensor,
        clip_denoised: bool = True,
        prediction_type: str = "epsilon",
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        计算 p(x_{t-1} | x_t) 的均值和方差

        参数:
            model_output: 模型输出 (噪声预测或 x_0 预测)
            x_t: 当前时间步的图像
            t: 时间步
            clip_denoised: 是否裁剪去噪后的值
            prediction_type: 预测类型 ("epsilon", "x_start", "v_prediction")

        返回:
            (模型均值, 后验方差, 后验对数方差)
        """
        # 从模型输出获取 x_0 预测
        if prediction_type == "epsilon":
            x_start = self.predict_start_from_noise(x_t, t, model_output)
        elif prediction_type == "x_start":
            x_start = model_output
        elif prediction_type == "v_prediction":
            # v = sqrt(alpha_bar) * noise - sqrt(1-alpha_bar) * x_0
            sqrt_alphas_cumprod_t = self._extract(self.sqrt_alphas_cumprod, t, x_t.shape)
            sqrt_one_minus_alphas_cumprod_t = self._extract(
                self.sqrt_one_minus_alphas_cumprod, t, x_t.shape
            )
            x_start = sqrt_alphas_cumprod_t * x_t - sqrt_one_minus_alphas_cumprod_t * model_output
        else:
            raise ValueError(f"Unknown prediction type: {prediction_type}")

        # 裁剪
        if clip_denoised:
            x_start = torch.clamp(x_start, -1.0, 1.0)

        # 计算后验均值和方差
        model_mean, posterior_variance, posterior_log_variance = self.q_posterior_mean_variance(
            x_start=x_start, x_t=x_t, t=t
        )

        return model_mean, posterior_variance, posterior_log_variance

    @torch.no_grad()
    def p_sample(
        self,
        model: nn.Module,
        x_t: torch.Tensor,
        t: torch.Tensor,
        y: torch.Tensor = None,
        clip_denoised: bool = True,
        prediction_type: str = "epsilon",
    ) -> torch.Tensor:
        """
        单步采样: p(x_{t-1} | x_t)

        参数:
            model: 噪声预测模型
            x_t: 当前时间步的图像
            t: 时间步
            y: 类别标签 (可选)
            clip_denoised: 是否裁剪
            prediction_type: 预测类型

        返回:
            x_{t-1}
        """
        # 模型预测
        model_output = model(x_t, t, y)

        # 计算均值和方差
        model_mean, _, model_log_variance = self.p_mean_variance(
            model_output=model_output,
            x_t=x_t,
            t=t,
            clip_denoised=clip_denoised,
            prediction_type=prediction_type,
        )

        # 添加噪声 (除了 t=0)
        noise = torch.randn_like(x_t)
        nonzero_mask = (t != 0).float().view(-1, *([1] * (len(x_t.shape) - 1)))

        return model_mean + nonzero_mask * torch.exp(0.5 * model_log_variance) * noise

    @torch.no_grad()
    def sample(
        self,
        model: nn.Module,
        shape: Tuple[int, ...],
        y: torch.Tensor = None,
        clip_denoised: bool = True,
        prediction_type: str = "epsilon",
        return_intermediates: bool = False,
    ) -> torch.Tensor:
        """
        完整采样过程

        参数:
            model: 噪声预测模型
            shape: 输出形状 (batch, channels, height, width)
            y: 类别标签 (可选)
            clip_denoised: 是否裁剪
            prediction_type: 预测类型
            return_intermediates: 是否返回中间结果

        返回:
            生成的图像
        """
        device = self.device
        batch_size = shape[0]

        # 从纯噪声开始
        x = torch.randn(shape, device=device)

        intermediates = []

        # 反向扩散
        for t in reversed(range(self.num_timesteps)):
            t_batch = torch.full((batch_size,), t, device=device, dtype=torch.long)
            x = self.p_sample(
                model=model,
                x_t=x,
                t=t_batch,
                y=y,
                clip_denoised=clip_denoised,
                prediction_type=prediction_type,
            )

            if return_intermediates:
                intermediates.append(x.clone())

        if return_intermediates:
            return x, intermediates

        return x


if __name__ == "__main__":
    # 测试代码
    print("=" * 60)
    print("噪声调度器测试")
    print("=" * 60)

    # 测试不同的调度策略
    timesteps = 1000
    schedules = ["linear", "cosine", "quadratic", "sigmoid"]

    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(2, 2, figsize=(12, 10))

    for idx, schedule in enumerate(schedules):
        ax = axes[idx // 2, idx % 2]

        scheduler = NoiseScheduler(
            num_timesteps=timesteps,
            beta_schedule=schedule,
        )

        # 绘制 beta
        ax.plot(scheduler.betas.numpy(), label="beta", alpha=0.7)
        ax.plot(scheduler.alphas_cumprod.numpy(), label="alpha_cumprod", alpha=0.7)
        ax.plot(scheduler.sqrt_alphas_cumprod.numpy(), label="sqrt_alpha_cumprod", alpha=0.7)
        ax.set_title(f"{schedule.capitalize()} Schedule")
        ax.set_xlabel("Timestep")
        ax.legend()
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig("/users/5/chen9005/FFF/dogs_diff/outputs/noise_schedules.png", dpi=150)
    print("噪声调度图已保存到 outputs/noise_schedules.png")

    # 测试前向扩散
    print("\n" + "-" * 40)
    print("测试前向扩散 q_sample")
    print("-" * 40)

    scheduler = DDPMScheduler(num_timesteps=1000, beta_schedule="cosine")

    # 创建假图像
    x_0 = torch.randn(4, 3, 64, 64)
    t = torch.tensor([0, 250, 500, 750])

    x_t = scheduler.q_sample(x_0, t)
    print(f"输入形状: {x_0.shape}")
    print(f"时间步: {t}")
    print(f"输出形状: {x_t.shape}")

    # 测试 SNR
    print("\n" + "-" * 40)
    print("测试信噪比 (SNR)")
    print("-" * 40)

    for t_val in [0, 250, 500, 750, 999]:
        snr = scheduler.get_snr(torch.tensor([t_val]))
        print(f"t={t_val}: SNR={snr.item():.4f}")

    print("\n测试完成!")
