"""
DDIM (Denoising Diffusion Implicit Models) 采样器

实现 DDIM 快速采样，可以在较少的步数内生成高质量图像
"""
from typing import List, Optional, Tuple, Union

import torch
import torch.nn as nn
import numpy as np
from tqdm import tqdm

from .scheduler import NoiseScheduler


class DDIMScheduler(NoiseScheduler):
    """
    DDIM 调度器

    实现 DDIM 论文中的确定性和随机性采样
    """

    def __init__(
        self,
        num_timesteps: int = 1000,
        beta_start: float = 1e-4,
        beta_end: float = 0.02,
        beta_schedule: str = "linear",
        device: str = "cpu",
        clip_sample: bool = True,
        set_alpha_to_one: bool = True,
        prediction_type: str = "epsilon",
    ):
        """
        参数:
            num_timesteps: 训练时的总时间步数
            beta_start: 起始 beta 值
            beta_end: 结束 beta 值
            beta_schedule: 调度类型
            device: 设备
            clip_sample: 是否裁剪样本到 [-1, 1]
            set_alpha_to_one: 是否将最终 alpha 设为 1
            prediction_type: 模型预测类型 ("epsilon", "x_start", "v_prediction")
        """
        super().__init__(
            num_timesteps=num_timesteps,
            beta_start=beta_start,
            beta_end=beta_end,
            beta_schedule=beta_schedule,
            device=device,
        )

        self.clip_sample = clip_sample
        self.prediction_type = prediction_type

        # DDIM 需要的额外参数
        if set_alpha_to_one:
            self.final_alpha_cumprod = torch.tensor(1.0)
        else:
            self.final_alpha_cumprod = self.alphas_cumprod[0]

    def _get_variance(
        self,
        timestep: int,
        prev_timestep: int,
    ) -> torch.Tensor:
        """
        计算 DDIM 方差 (数值稳定版本)

        参数:
            timestep: 当前时间步
            prev_timestep: 上一个时间步

        返回:
            方差值
        """
        eps = 1e-8

        alpha_prod_t = self.alphas_cumprod[timestep]
        alpha_prod_t_prev = (
            self.alphas_cumprod[prev_timestep]
            if prev_timestep >= 0
            else self.final_alpha_cumprod
        )

        beta_prod_t = 1 - alpha_prod_t
        beta_prod_t_prev = 1 - alpha_prod_t_prev

        # 数值稳定性：防止除零和数值爆炸
        beta_prod_t_safe = torch.clamp(beta_prod_t, min=eps)
        alpha_prod_t_prev_safe = torch.clamp(alpha_prod_t_prev, min=eps)

        # 计算方差，确保结果非负
        variance = (beta_prod_t_prev / beta_prod_t_safe) * (1 - alpha_prod_t / alpha_prod_t_prev_safe)
        variance = torch.clamp(variance, min=0.0)

        return variance

    def set_timesteps(
        self,
        num_inference_steps: int,
        device: str = None,
    ) -> torch.Tensor:
        """
        设置采样时间步

        参数:
            num_inference_steps: 采样步数
            device: 设备

        返回:
            时间步序列
        """
        if device is None:
            device = self.device

        # 均匀分布的时间步，从 num_timesteps-1 到 0
        # 确保第一步从最大时间步开始（纯噪声）
        timesteps = np.linspace(
            0, self.num_timesteps - 1, num_inference_steps, dtype=np.float64
        )
        timesteps = np.round(timesteps)[::-1].copy().astype(np.int64)
        self.timesteps = torch.from_numpy(timesteps).to(device)

        return self.timesteps

    @torch.no_grad()
    def step(
        self,
        model_output: torch.Tensor,
        timestep: int,
        sample: torch.Tensor,
        eta: float = 0.0,
        use_clipped_model_output: bool = False,
        generator: torch.Generator = None,
        prev_timestep: int = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        DDIM 单步采样 (数值稳定版本，特别优化低时间步)

        参数:
            model_output: 模型输出
            timestep: 当前时间步
            sample: 当前样本
            eta: 控制随机性 (0=确定性DDIM, 1=DDPM)
            use_clipped_model_output: 是否使用裁剪后的模型输出
            generator: 随机数生成器
            prev_timestep: 上一个时间步

        返回:
            (上一步样本, 预测的 x_0)
        """
        # 数值稳定性常数
        eps = 1e-8

        # 首先处理输入中的 NaN/Inf
        if torch.isnan(model_output).any() or torch.isinf(model_output).any():
            model_output = torch.nan_to_num(model_output, nan=0.0, posinf=0.0, neginf=0.0)
        if torch.isnan(sample).any() or torch.isinf(sample).any():
            sample = torch.nan_to_num(sample, nan=0.0, posinf=0.0, neginf=0.0)

        if prev_timestep is None:
            # 找到上一个时间步
            timestep_idx = (self.timesteps == timestep).nonzero().item()
            prev_timestep = (
                self.timesteps[timestep_idx + 1].item()
                if timestep_idx < len(self.timesteps) - 1
                else -1
            )

        # 获取 alpha 值
        alpha_prod_t = self.alphas_cumprod[timestep]
        alpha_prod_t_prev = (
            self.alphas_cumprod[prev_timestep]
            if prev_timestep >= 0
            else self.final_alpha_cumprod
        )

        beta_prod_t = 1 - alpha_prod_t

        # ============================================================
        # 低时间步特殊处理 (t < 50)
        # 当 t 很小时，beta_prod_t 接近 0，会导致数值不稳定
        # ============================================================
        is_low_timestep = timestep < 50

        # 对于低时间步，使用更保守的 eps 值
        if is_low_timestep:
            eps_safe = 1e-4  # 更大的 eps 防止除零
        else:
            eps_safe = eps

        # 确保 alpha 和 beta 有合理的最小值，防止除零
        alpha_prod_t_safe = torch.clamp(alpha_prod_t, min=eps_safe, max=1.0 - eps_safe)
        beta_prod_t_safe = torch.clamp(beta_prod_t, min=eps_safe, max=1.0 - eps_safe)

        # 从模型输出计算 x_0 预测
        if self.prediction_type == "epsilon":
            # 使用安全的 alpha 值进行除法
            pred_original_sample = (
                sample - beta_prod_t_safe ** 0.5 * model_output
            ) / (alpha_prod_t_safe ** 0.5)
        elif self.prediction_type == "x_start":
            pred_original_sample = model_output
        elif self.prediction_type == "v_prediction":
            pred_original_sample = (
                alpha_prod_t_safe ** 0.5 * sample - beta_prod_t_safe ** 0.5 * model_output
            )
        else:
            raise ValueError(f"Unknown prediction type: {self.prediction_type}")

        # 处理 pred_original_sample 中的 NaN/Inf
        if torch.isnan(pred_original_sample).any() or torch.isinf(pred_original_sample).any():
            pred_original_sample = torch.nan_to_num(pred_original_sample, nan=0.0, posinf=1.0, neginf=-1.0)

        # 裁剪预测的 x_0 到合理范围
        if self.clip_sample:
            pred_original_sample = torch.clamp(pred_original_sample, -1.0, 1.0)

        # ============================================================
        # 低时间步时直接返回 pred_original_sample
        # 因为此时 sample 已经非常接近最终图像
        # ============================================================
        if prev_timestep < 0:
            # 这是最后一步，直接返回预测的 x_0
            return pred_original_sample, pred_original_sample

        # 计算预测的噪声
        if self.prediction_type == "epsilon":
            pred_epsilon = model_output
        elif self.prediction_type == "x_start":
            pred_epsilon = (
                sample - alpha_prod_t_safe ** 0.5 * pred_original_sample
            ) / (beta_prod_t_safe ** 0.5)
        elif self.prediction_type == "v_prediction":
            pred_epsilon = alpha_prod_t_safe ** 0.5 * model_output + beta_prod_t_safe ** 0.5 * sample

        if use_clipped_model_output:
            # 使用裁剪后的 x_0 重新计算噪声
            pred_epsilon = (
                sample - alpha_prod_t_safe ** 0.5 * pred_original_sample
            ) / (beta_prod_t_safe ** 0.5)

        # 限制 pred_epsilon 的范围，防止数值爆炸
        # 对于低时间步，使用更严格的限制
        if is_low_timestep:
            pred_epsilon = torch.clamp(pred_epsilon, -5.0, 5.0)
        else:
            pred_epsilon = torch.clamp(pred_epsilon, -10.0, 10.0)

        # 计算方差
        variance = self._get_variance(timestep, prev_timestep)
        std_dev_t = eta * (variance ** 0.5)

        # DDIM 公式
        # x_{t-1} = sqrt(alpha_{t-1}) * x_0 + sqrt(1 - alpha_{t-1} - sigma^2) * epsilon + sigma * noise
        # 确保开方参数非负
        direction_coef = 1 - alpha_prod_t_prev - std_dev_t ** 2
        direction_coef = torch.clamp(direction_coef, min=0.0, max=1.0)
        pred_sample_direction = (direction_coef ** 0.5) * pred_epsilon

        prev_sample = (
            alpha_prod_t_prev ** 0.5 * pred_original_sample + pred_sample_direction
        )

        # 添加噪声 (如果 eta > 0)
        if eta > 0:
            if generator is not None:
                noise = torch.randn(
                    sample.shape, generator=generator, device=sample.device, dtype=sample.dtype
                )
            else:
                noise = torch.randn_like(sample)
            prev_sample = prev_sample + std_dev_t * noise

        # 最终 NaN/Inf 处理和裁剪
        if torch.isnan(prev_sample).any() or torch.isinf(prev_sample).any():
            prev_sample = torch.nan_to_num(prev_sample, nan=0.0, posinf=1.0, neginf=-1.0)

        # 对于低时间步，额外进行裁剪以确保数值范围合理
        if is_low_timestep:
            prev_sample = torch.clamp(prev_sample, -2.0, 2.0)

        return prev_sample, pred_original_sample

    @torch.no_grad()
    def sample(
        self,
        model: nn.Module,
        shape: Tuple[int, ...],
        num_inference_steps: int = 50,
        eta: float = 0.0,
        y: torch.Tensor = None,
        guidance_scale: float = 1.0,
        generator: torch.Generator = None,
        return_intermediates: bool = False,
        show_progress: bool = True,
    ) -> Union[torch.Tensor, Tuple[torch.Tensor, List[torch.Tensor]]]:
        """
        DDIM 完整采样

        参数:
            model: 噪声预测模型
            shape: 输出形状
            num_inference_steps: 采样步数
            eta: 随机性控制 (0=确定性, 1=DDPM)
            y: 类别标签 (可选)
            guidance_scale: CFG 强度
            generator: 随机数生成器
            return_intermediates: 是否返回中间结果
            show_progress: 是否显示进度条

        返回:
            生成的图像 (和可选的中间结果)
        """
        device = self.device
        batch_size = shape[0]

        # 设置时间步
        self.set_timesteps(num_inference_steps, device)

        # 从纯噪声开始
        if generator is not None:
            sample = torch.randn(shape, generator=generator, device=device)
        else:
            sample = torch.randn(shape, device=device)

        intermediates = []

        # 迭代采样
        timesteps_iter = tqdm(self.timesteps, desc="DDIM Sampling", mininterval=5, ncols=80) if show_progress else self.timesteps

        for t in timesteps_iter:
            t_batch = torch.full((batch_size,), t, device=device, dtype=torch.long)

            # 模型预测
            if guidance_scale > 1.0 and y is not None:
                # Classifier-Free Guidance
                # 有条件预测
                noise_pred_cond = model(sample, t_batch, y)
                # 无条件预测
                noise_pred_uncond = model(sample, t_batch, None)
                # CFG 组合
                model_output = noise_pred_uncond + guidance_scale * (noise_pred_cond - noise_pred_uncond)
            else:
                model_output = model(sample, t_batch, y)

            # DDIM 步进
            sample, pred_x0 = self.step(
                model_output=model_output,
                timestep=t.item(),
                sample=sample,
                eta=eta,
                generator=generator,
            )

            if return_intermediates:
                intermediates.append(sample.clone())

        if return_intermediates:
            return sample, intermediates

        return sample

    @torch.no_grad()
    def sample_with_cfg(
        self,
        model: nn.Module,
        shape: Tuple[int, ...],
        y: torch.Tensor,
        num_inference_steps: int = 50,
        guidance_scale: float = 7.5,
        eta: float = 0.0,
        generator: torch.Generator = None,
        show_progress: bool = True,
    ) -> torch.Tensor:
        """
        使用 Classifier-Free Guidance 的 DDIM 采样

        参数:
            model: 噪声预测模型
            shape: 输出形状
            y: 类别标签
            num_inference_steps: 采样步数
            guidance_scale: CFG 强度
            eta: 随机性控制
            generator: 随机数生成器
            show_progress: 是否显示进度条

        返回:
            生成的图像
        """
        return self.sample(
            model=model,
            shape=shape,
            num_inference_steps=num_inference_steps,
            eta=eta,
            y=y,
            guidance_scale=guidance_scale,
            generator=generator,
            return_intermediates=False,
            show_progress=show_progress,
        )


class DDIMInversion:
    """
    DDIM 反演

    将真实图像转换回噪声空间，用于图像编辑
    """

    def __init__(self, scheduler: DDIMScheduler):
        """
        参数:
            scheduler: DDIM 调度器
        """
        self.scheduler = scheduler

    @torch.no_grad()
    def invert(
        self,
        model: nn.Module,
        image: torch.Tensor,
        num_inference_steps: int = 50,
        y: torch.Tensor = None,
        guidance_scale: float = 1.0,
        show_progress: bool = True,
    ) -> Tuple[torch.Tensor, List[torch.Tensor]]:
        """
        DDIM 反演: 从图像恢复潜在噪声

        参数:
            model: 噪声预测模型
            image: 输入图像 [batch, channels, height, width]
            num_inference_steps: 反演步数
            y: 类别标签 (可选)
            guidance_scale: CFG 强度
            show_progress: 是否显示进度条

        返回:
            (最终噪声, 中间潜在表示列表)
        """
        device = self.scheduler.device
        batch_size = image.shape[0]

        # 设置时间步 (反向顺序)
        self.scheduler.set_timesteps(num_inference_steps, device)
        timesteps = torch.flip(self.scheduler.timesteps, dims=[0])

        latents = [image]
        current = image

        timesteps_iter = tqdm(timesteps, desc="DDIM Inversion", mininterval=5, ncols=80) if show_progress else timesteps

        for i, t in enumerate(timesteps_iter):
            t_batch = torch.full((batch_size,), t, device=device, dtype=torch.long)

            # 模型预测
            if guidance_scale > 1.0 and y is not None:
                noise_pred_cond = model(current, t_batch, y)
                noise_pred_uncond = model(current, t_batch, None)
                noise_pred = noise_pred_uncond + guidance_scale * (noise_pred_cond - noise_pred_uncond)
            else:
                noise_pred = model(current, t_batch, y)

            # 计算下一个时间步
            next_timestep = timesteps[i + 1].item() if i < len(timesteps) - 1 else self.scheduler.num_timesteps

            # 获取 alpha 值
            alpha_prod_t = self.scheduler.alphas_cumprod[t]
            alpha_prod_t_next = self.scheduler.alphas_cumprod[next_timestep]

            beta_prod_t = 1 - alpha_prod_t

            # 预测 x_0
            if self.scheduler.prediction_type == "epsilon":
                pred_x0 = (current - beta_prod_t ** 0.5 * noise_pred) / alpha_prod_t ** 0.5
            elif self.scheduler.prediction_type == "x_start":
                pred_x0 = noise_pred
            else:
                raise ValueError(f"Unknown prediction type: {self.scheduler.prediction_type}")

            # 计算方向
            pred_dir = (1 - alpha_prod_t_next) ** 0.5 * noise_pred

            # 反演步进
            current = alpha_prod_t_next ** 0.5 * pred_x0 + pred_dir
            latents.append(current)

        return current, latents


def make_ddim_timesteps(
    ddim_discr_method: str,
    num_ddim_timesteps: int,
    num_ddpm_timesteps: int,
) -> np.ndarray:
    """
    创建 DDIM 时间步子集

    参数:
        ddim_discr_method: 离散化方法 ("uniform", "quad")
        num_ddim_timesteps: DDIM 时间步数
        num_ddpm_timesteps: 原始 DDPM 时间步数

    返回:
        DDIM 时间步数组
    """
    if ddim_discr_method == "uniform":
        c = num_ddpm_timesteps // num_ddim_timesteps
        ddim_timesteps = np.asarray(list(range(0, num_ddpm_timesteps, c)))
    elif ddim_discr_method == "quad":
        ddim_timesteps = (
            (np.linspace(0, np.sqrt(num_ddpm_timesteps * 0.8), num_ddim_timesteps)) ** 2
        ).astype(int)
    else:
        raise NotImplementedError(f"Unknown discretization method: {ddim_discr_method}")

    # 添加最后一个时间步
    ddim_timesteps = ddim_timesteps + 1

    return ddim_timesteps


if __name__ == "__main__":
    # 测试代码
    print("=" * 60)
    print("DDIM 采样器测试")
    print("=" * 60)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"使用设备: {device}")

    # 创建 DDIM 调度器
    scheduler = DDIMScheduler(
        num_timesteps=1000,
        beta_schedule="cosine",
        device=device,
    )

    print("\n" + "-" * 40)
    print("测试时间步设置")
    print("-" * 40)

    # 设置不同的采样步数
    for steps in [10, 25, 50, 100]:
        timesteps = scheduler.set_timesteps(steps)
        print(f"采样步数 {steps}: {len(timesteps)} 步, 时间步范围 [{timesteps[-1].item()}, {timesteps[0].item()}]")

    print("\n" + "-" * 40)
    print("测试方差计算")
    print("-" * 40)

    scheduler.set_timesteps(50)
    for i in range(0, len(scheduler.timesteps) - 1, 10):
        t = scheduler.timesteps[i].item()
        prev_t = scheduler.timesteps[i + 1].item()
        variance = scheduler._get_variance(t, prev_t)
        print(f"t={t} -> t={prev_t}: variance={variance.item():.6f}")

    print("\n" + "-" * 40)
    print("测试 make_ddim_timesteps")
    print("-" * 40)

    for method in ["uniform", "quad"]:
        timesteps = make_ddim_timesteps(method, 50, 1000)
        print(f"{method}: {timesteps[:5]}...{timesteps[-5:]}")

    print("\n测试完成!")
