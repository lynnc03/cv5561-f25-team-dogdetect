"""
视觉感知损失函数模块

包含多种用于提升扩散模型生成质量的损失函数:
- SSIM Loss: 结构相似性损失
- Perceptual Loss: VGG感知损失
- Frequency Loss: 频率域损失
- Multi-Scale Loss: 多尺度损失
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, List, Tuple
import math


class SSIMLoss(nn.Module):
    """
    SSIM (Structural Similarity Index) 损失

    衡量图像结构相似性，对亮度、对比度和结构进行评估
    比MSE更符合人类视觉感知
    """

    def __init__(
        self,
        window_size: int = 11,
        sigma: float = 1.5,
        channel: int = 3,
        size_average: bool = True,
        data_range: float = 2.0,  # [-1, 1] 范围
    ):
        super().__init__()
        self.window_size = window_size
        self.sigma = sigma
        self.channel = channel
        self.size_average = size_average
        self.data_range = data_range

        # 创建高斯窗口
        self.register_buffer('window', self._create_window(window_size, channel, sigma))

    def _create_window(self, window_size: int, channel: int, sigma: float) -> torch.Tensor:
        """创建高斯窗口"""
        gauss = torch.Tensor([
            math.exp(-(x - window_size // 2) ** 2 / (2 * sigma ** 2))
            for x in range(window_size)
        ])
        gauss = gauss / gauss.sum()

        # 2D高斯核
        _1D_window = gauss.unsqueeze(1)
        _2D_window = _1D_window.mm(_1D_window.t()).float().unsqueeze(0).unsqueeze(0)

        # 扩展到多通道
        window = _2D_window.expand(channel, 1, window_size, window_size).contiguous()
        return window

    def _ssim(
        self,
        img1: torch.Tensor,
        img2: torch.Tensor,
        window: torch.Tensor,
        window_size: int,
        channel: int,
    ) -> torch.Tensor:
        """计算SSIM"""
        C1 = (0.01 * self.data_range) ** 2
        C2 = (0.03 * self.data_range) ** 2

        mu1 = F.conv2d(img1, window, padding=window_size // 2, groups=channel)
        mu2 = F.conv2d(img2, window, padding=window_size // 2, groups=channel)

        mu1_sq = mu1.pow(2)
        mu2_sq = mu2.pow(2)
        mu1_mu2 = mu1 * mu2

        sigma1_sq = F.conv2d(img1 * img1, window, padding=window_size // 2, groups=channel) - mu1_sq
        sigma2_sq = F.conv2d(img2 * img2, window, padding=window_size // 2, groups=channel) - mu2_sq
        sigma12 = F.conv2d(img1 * img2, window, padding=window_size // 2, groups=channel) - mu1_mu2

        ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / \
                   ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))

        if self.size_average:
            return ssim_map.mean()
        else:
            return ssim_map.mean(1).mean(1).mean(1)

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """
        计算SSIM损失 (1 - SSIM)

        参数:
            pred: 预测图像 [B, C, H, W]
            target: 目标图像 [B, C, H, W]

        返回:
            SSIM损失值
        """
        channel = pred.size(1)

        if channel != self.channel:
            window = self._create_window(self.window_size, channel, self.sigma).to(pred.device)
        else:
            window = self.window.to(pred.device)

        ssim_val = self._ssim(pred, target, window, self.window_size, channel)
        return 1.0 - ssim_val


class MultiScaleSSIMLoss(nn.Module):
    """
    多尺度SSIM损失

    在多个尺度上计算SSIM，更好地捕捉不同频率的信息
    """

    def __init__(
        self,
        window_size: int = 11,
        channel: int = 3,
        weights: List[float] = None,
        data_range: float = 2.0,
    ):
        super().__init__()
        self.weights = weights or [0.0448, 0.2856, 0.3001, 0.2363, 0.1333]
        self.ssim = SSIMLoss(window_size=window_size, channel=channel, data_range=data_range)

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """计算多尺度SSIM损失"""
        levels = len(self.weights)
        ms_ssim_val = 1.0

        for i in range(levels):
            ssim_val = 1.0 - self.ssim(pred, target)  # SSIM值

            if i < levels - 1:
                pred = F.avg_pool2d(pred, kernel_size=2, stride=2)
                target = F.avg_pool2d(target, kernel_size=2, stride=2)

            ms_ssim_val *= ssim_val ** self.weights[i]

        return 1.0 - ms_ssim_val


class PerceptualLoss(nn.Module):
    """
    VGG感知损失

    使用预训练VGG网络提取特征，计算特征空间的距离
    能够捕捉高级语义信息
    """

    def __init__(
        self,
        layers: List[str] = None,
        weights: List[float] = None,
        normalize_input: bool = True,
        requires_grad: bool = False,
    ):
        super().__init__()

        self.layers = layers or ['relu1_2', 'relu2_2', 'relu3_4', 'relu4_4']
        self.weights = weights or [1.0, 1.0, 1.0, 1.0]
        self.normalize_input = normalize_input

        # 加载VGG模型
        try:
            from torchvision.models import vgg19, VGG19_Weights
            vgg = vgg19(weights=VGG19_Weights.IMAGENET1K_V1).features
        except:
            from torchvision.models import vgg19
            vgg = vgg19(pretrained=True).features

        # 选择需要的层
        self.slices = nn.ModuleList()
        self._build_slices(vgg)

        # 冻结参数
        if not requires_grad:
            for param in self.parameters():
                param.requires_grad = False

        # ImageNet归一化参数
        self.register_buffer('mean', torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer('std', torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))

    def _build_slices(self, vgg: nn.Module):
        """构建VGG子网络切片"""
        layer_name_mapping = {
            'relu1_1': 1, 'relu1_2': 3,
            'relu2_1': 6, 'relu2_2': 8,
            'relu3_1': 11, 'relu3_2': 13, 'relu3_3': 15, 'relu3_4': 17,
            'relu4_1': 20, 'relu4_2': 22, 'relu4_3': 24, 'relu4_4': 26,
            'relu5_1': 29, 'relu5_2': 31, 'relu5_3': 33, 'relu5_4': 35,
        }

        prev_idx = 0
        for layer_name in self.layers:
            idx = layer_name_mapping[layer_name]
            self.slices.append(nn.Sequential(*list(vgg.children())[prev_idx:idx + 1]))
            prev_idx = idx + 1

    def _normalize(self, x: torch.Tensor) -> torch.Tensor:
        """将输入从[-1,1]转换为ImageNet归一化"""
        # 先转换到[0,1]
        x = (x + 1) / 2
        # ImageNet归一化
        return (x - self.mean.to(x.device)) / self.std.to(x.device)

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """
        计算感知损失

        参数:
            pred: 预测图像 [B, C, H, W], 范围[-1, 1]
            target: 目标图像 [B, C, H, W], 范围[-1, 1]

        返回:
            感知损失值
        """
        if self.normalize_input:
            pred = self._normalize(pred)
            target = self._normalize(target)

        loss = 0.0
        pred_feat = pred
        target_feat = target

        for i, slice_net in enumerate(self.slices):
            pred_feat = slice_net(pred_feat)
            target_feat = slice_net(target_feat)
            loss += self.weights[i] * F.l1_loss(pred_feat, target_feat)

        return loss


class FrequencyLoss(nn.Module):
    """
    频率域损失

    在傅里叶变换域计算损失，帮助生成更清晰的高频细节
    """

    def __init__(
        self,
        loss_type: str = 'l1',
        avg_spectrum: bool = False,
        log_amplitude: bool = True,
    ):
        super().__init__()
        self.loss_type = loss_type
        self.avg_spectrum = avg_spectrum
        self.log_amplitude = log_amplitude

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """
        计算频率域损失

        参数:
            pred: 预测图像 [B, C, H, W]
            target: 目标图像 [B, C, H, W]

        返回:
            频率损失值
        """
        # 2D FFT
        pred_fft = torch.fft.fft2(pred, norm='ortho')
        target_fft = torch.fft.fft2(target, norm='ortho')

        # 幅度谱
        pred_amp = torch.abs(pred_fft)
        target_amp = torch.abs(target_fft)

        if self.log_amplitude:
            pred_amp = torch.log(pred_amp + 1e-8)
            target_amp = torch.log(target_amp + 1e-8)

        if self.avg_spectrum:
            pred_amp = pred_amp.mean(dim=1, keepdim=True)
            target_amp = target_amp.mean(dim=1, keepdim=True)

        # 相位谱
        pred_phase = torch.angle(pred_fft)
        target_phase = torch.angle(target_fft)

        # 计算损失
        if self.loss_type == 'l1':
            amp_loss = F.l1_loss(pred_amp, target_amp)
            phase_loss = F.l1_loss(pred_phase, target_phase)
        else:
            amp_loss = F.mse_loss(pred_amp, target_amp)
            phase_loss = F.mse_loss(pred_phase, target_phase)

        return amp_loss + 0.1 * phase_loss


class EdgeLoss(nn.Module):
    """
    边缘感知损失

    使用Sobel算子提取边缘，增强生成图像的锐利度
    """

    def __init__(self):
        super().__init__()
        # Sobel算子
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32)

        self.register_buffer('sobel_x', sobel_x.view(1, 1, 3, 3).repeat(3, 1, 1, 1))
        self.register_buffer('sobel_y', sobel_y.view(1, 1, 3, 3).repeat(3, 1, 1, 1))

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """计算边缘损失"""
        pred_edge_x = F.conv2d(pred, self.sobel_x.to(pred.device), padding=1, groups=3)
        pred_edge_y = F.conv2d(pred, self.sobel_y.to(pred.device), padding=1, groups=3)
        pred_edge = torch.sqrt(pred_edge_x ** 2 + pred_edge_y ** 2 + 1e-8)

        target_edge_x = F.conv2d(target, self.sobel_x.to(target.device), padding=1, groups=3)
        target_edge_y = F.conv2d(target, self.sobel_y.to(target.device), padding=1, groups=3)
        target_edge = torch.sqrt(target_edge_x ** 2 + target_edge_y ** 2 + 1e-8)

        return F.l1_loss(pred_edge, target_edge)


class CombinedDiffusionLoss(nn.Module):
    """
    组合扩散损失

    结合多种损失函数用于扩散模型训练:
    - 基础MSE/L1损失 (噪声预测)
    - SSIM损失 (结构相似性)
    - 感知损失 (语义特征)
    - 频率损失 (高频细节)
    - 边缘损失 (锐利度)
    """

    def __init__(
        self,
        base_loss_type: str = 'l2',
        use_ssim: bool = True,
        use_perceptual: bool = False,  # 计算开销大，可选
        use_frequency: bool = True,
        use_edge: bool = True,
        ssim_weight: float = 0.1,
        perceptual_weight: float = 0.01,
        frequency_weight: float = 0.05,
        edge_weight: float = 0.05,
        apply_on_x0: bool = True,  # 是否在预测的x0上计算视觉损失
    ):
        super().__init__()

        self.base_loss_type = base_loss_type
        self.apply_on_x0 = apply_on_x0

        # 权重
        self.ssim_weight = ssim_weight
        self.perceptual_weight = perceptual_weight
        self.frequency_weight = frequency_weight
        self.edge_weight = edge_weight

        # 损失函数
        self.use_ssim = use_ssim
        self.use_perceptual = use_perceptual
        self.use_frequency = use_frequency
        self.use_edge = use_edge

        # 始终初始化SSIM和Edge损失函数，以支持动态启用
        self.ssim_loss = SSIMLoss()
        self.edge_loss = EdgeLoss()

        if use_perceptual:
            self.perceptual_loss = PerceptualLoss()

        if use_frequency:
            self.frequency_loss = FrequencyLoss()

    def forward(
        self,
        model_output: torch.Tensor,
        target: torch.Tensor,
        x_start: torch.Tensor = None,
        pred_x_start: torch.Tensor = None,
    ) -> Tuple[torch.Tensor, dict]:
        """
        计算组合损失

        参数:
            model_output: 模型预测的噪声
            target: 目标噪声
            x_start: 原始图像 (用于计算视觉损失)
            pred_x_start: 预测的原始图像 (用于计算视觉损失)

        返回:
            (总损失, 各分量损失字典)
        """
        loss_dict = {}

        # 基础损失 (噪声预测)
        if self.base_loss_type == 'l1':
            base_loss = F.l1_loss(model_output, target)
        elif self.base_loss_type == 'l2':
            base_loss = F.mse_loss(model_output, target)
        elif self.base_loss_type == 'huber':
            base_loss = F.smooth_l1_loss(model_output, target)
        else:
            raise ValueError(f"Unknown base loss type: {self.base_loss_type}")

        loss_dict['base_loss'] = base_loss.item()
        total_loss = base_loss

        # 视觉损失 (在预测的x0和真实x0之间计算)
        if self.apply_on_x0 and x_start is not None and pred_x_start is not None:
            # SSIM损失
            if self.use_ssim:
                ssim_loss = self.ssim_loss(pred_x_start, x_start)
                loss_dict['ssim_loss'] = ssim_loss.item()
                total_loss = total_loss + self.ssim_weight * ssim_loss

            # 感知损失
            if self.use_perceptual:
                perceptual_loss = self.perceptual_loss(pred_x_start, x_start)
                loss_dict['perceptual_loss'] = perceptual_loss.item()
                total_loss = total_loss + self.perceptual_weight * perceptual_loss

            # 频率损失
            if self.use_frequency:
                freq_loss = self.frequency_loss(pred_x_start, x_start)
                loss_dict['frequency_loss'] = freq_loss.item()
                total_loss = total_loss + self.frequency_weight * freq_loss

            # 边缘损失
            if self.use_edge:
                edge_loss = self.edge_loss(pred_x_start, x_start)
                loss_dict['edge_loss'] = edge_loss.item()
                total_loss = total_loss + self.edge_weight * edge_loss

        loss_dict['total_loss'] = total_loss.item()

        return total_loss, loss_dict


class VelocityPredictionLoss(nn.Module):
    """
    v-prediction 损失

    用于v-prediction目标的损失计算，可以提高低SNR时间步的训练稳定性
    """

    def __init__(self, loss_type: str = 'l2'):
        super().__init__()
        self.loss_type = loss_type

    def forward(
        self,
        v_pred: torch.Tensor,
        v_target: torch.Tensor,
        snr_weights: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        计算v-prediction损失

        参数:
            v_pred: 预测的速度
            v_target: 目标速度
            snr_weights: SNR加权 (可选)

        返回:
            损失值
        """
        if self.loss_type == 'l1':
            loss = F.l1_loss(v_pred, v_target, reduction='none')
        else:
            loss = F.mse_loss(v_pred, v_target, reduction='none')

        loss = loss.mean(dim=[1, 2, 3])

        if snr_weights is not None:
            loss = loss * snr_weights

        return loss.mean()


class MinSNRWeighting:
    """
    Min-SNR加权策略

    来自 "Efficient Diffusion Training via Min-SNR Weighting Strategy" 论文
    通过调整不同时间步的损失权重来改善训练
    """

    def __init__(self, gamma: float = 5.0):
        self.gamma = gamma

    def __call__(self, snr: torch.Tensor) -> torch.Tensor:
        """
        计算Min-SNR权重

        参数:
            snr: 信噪比 [batch_size]

        返回:
            损失权重
        """
        return torch.clamp(snr, max=self.gamma) / self.gamma


if __name__ == "__main__":
    # 测试代码
    print("=" * 60)
    print("视觉损失函数测试")
    print("=" * 60)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"使用设备: {device}")

    # 创建测试数据
    batch_size = 4
    img1 = torch.randn(batch_size, 3, 64, 64, device=device)
    img2 = img1 + 0.1 * torch.randn_like(img1)

    # 测试SSIM损失
    print("\n" + "-" * 40)
    print("测试 SSIM 损失")
    print("-" * 40)
    ssim_loss = SSIMLoss().to(device)
    loss = ssim_loss(img1, img2)
    print(f"SSIM损失: {loss.item():.4f}")

    # 测试感知损失
    print("\n" + "-" * 40)
    print("测试感知损失")
    print("-" * 40)
    try:
        perceptual_loss = PerceptualLoss().to(device)
        loss = perceptual_loss(img1, img2)
        print(f"感知损失: {loss.item():.4f}")
    except Exception as e:
        print(f"感知损失测试跳过: {e}")

    # 测试频率损失
    print("\n" + "-" * 40)
    print("测试频率损失")
    print("-" * 40)
    freq_loss = FrequencyLoss().to(device)
    loss = freq_loss(img1, img2)
    print(f"频率损失: {loss.item():.4f}")

    # 测试边缘损失
    print("\n" + "-" * 40)
    print("测试边缘损失")
    print("-" * 40)
    edge_loss = EdgeLoss().to(device)
    loss = edge_loss(img1, img2)
    print(f"边缘损失: {loss.item():.4f}")

    # 测试组合损失
    print("\n" + "-" * 40)
    print("测试组合损失")
    print("-" * 40)
    combined_loss = CombinedDiffusionLoss(
        use_ssim=True,
        use_perceptual=False,  # 跳过感知损失以加速测试
        use_frequency=True,
        use_edge=True,
    ).to(device)

    noise_pred = torch.randn(batch_size, 3, 64, 64, device=device)
    noise_target = noise_pred + 0.1 * torch.randn_like(noise_pred)

    total_loss, loss_dict = combined_loss(
        model_output=noise_pred,
        target=noise_target,
        x_start=img1,
        pred_x_start=img2,
    )
    print(f"组合损失: {total_loss.item():.4f}")
    print(f"损失分量: {loss_dict}")

    print("\n测试完成!")
