"""
UNet 基础构建块
- 残差块 (ResBlock)
- 上采样 (Upsample)
- 下采样 (Downsample)
"""
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


def zero_module(module: nn.Module) -> nn.Module:
    """
    将模块的所有参数初始化为零
    用于残差连接的初始化
    """
    for p in module.parameters():
        p.detach().zero_()
    return module


def conv_nd(dims: int, *args, **kwargs) -> nn.Module:
    """
    创建 N 维卷积层
    """
    if dims == 1:
        return nn.Conv1d(*args, **kwargs)
    elif dims == 2:
        return nn.Conv2d(*args, **kwargs)
    elif dims == 3:
        return nn.Conv3d(*args, **kwargs)
    raise ValueError(f"unsupported dimensions: {dims}")


def avg_pool_nd(dims: int, *args, **kwargs) -> nn.Module:
    """
    创建 N 维平均池化层
    """
    if dims == 1:
        return nn.AvgPool1d(*args, **kwargs)
    elif dims == 2:
        return nn.AvgPool2d(*args, **kwargs)
    elif dims == 3:
        return nn.AvgPool3d(*args, **kwargs)
    raise ValueError(f"unsupported dimensions: {dims}")


class TimestepBlock(nn.Module):
    """
    时间步条件块的抽象基类

    任何需要时间步嵌入的模块都应该继承这个类
    """

    def forward(self, x: torch.Tensor, emb: torch.Tensor) -> torch.Tensor:
        """
        参数:
            x: 输入张量
            emb: 时间步嵌入

        返回:
            输出张量
        """
        raise NotImplementedError


class GroupNorm32(nn.GroupNorm):
    """
    使用 float32 计算的 GroupNorm，提高数值稳定性
    """

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return super().forward(x.float()).type(x.dtype)


def normalization(channels: int, num_groups: int = 32) -> nn.Module:
    """
    创建归一化层
    """
    return GroupNorm32(min(num_groups, channels), channels)


class Downsample(nn.Module):
    """
    下采样模块

    使用步长为2的卷积进行下采样，保持通道数不变或增加通道数
    """

    def __init__(
        self,
        channels: int,
        use_conv: bool = True,
        dims: int = 2,
        out_channels: int = None,
        padding: int = 1,
    ):
        """
        参数:
            channels: 输入通道数
            use_conv: 是否使用卷积下采样 (否则使用平均池化)
            dims: 空间维度数
            out_channels: 输出通道数 (默认与输入相同)
            padding: 填充大小
        """
        super().__init__()

        self.channels = channels
        self.out_channels = out_channels or channels
        self.use_conv = use_conv
        self.dims = dims

        stride = 2
        if use_conv:
            self.op = conv_nd(
                dims,
                channels,
                self.out_channels,
                kernel_size=3,
                stride=stride,
                padding=padding,
            )
        else:
            assert channels == self.out_channels
            self.op = avg_pool_nd(dims, kernel_size=stride, stride=stride)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        参数:
            x: 输入张量

        返回:
            下采样后的张量
        """
        return self.op(x)


class Upsample(nn.Module):
    """
    上采样模块

    使用最近邻插值进行上采样，然后通过卷积调整通道数
    """

    def __init__(
        self,
        channels: int,
        use_conv: bool = True,
        dims: int = 2,
        out_channels: int = None,
        padding: int = 1,
    ):
        """
        参数:
            channels: 输入通道数
            use_conv: 是否在上采样后使用卷积
            dims: 空间维度数
            out_channels: 输出通道数 (默认与输入相同)
            padding: 填充大小
        """
        super().__init__()

        self.channels = channels
        self.out_channels = out_channels or channels
        self.use_conv = use_conv
        self.dims = dims

        if use_conv:
            self.conv = conv_nd(
                dims,
                channels,
                self.out_channels,
                kernel_size=3,
                padding=padding,
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        参数:
            x: 输入张量

        返回:
            上采样后的张量
        """
        # 最近邻插值上采样
        x = F.interpolate(x, scale_factor=2, mode="nearest")

        if self.use_conv:
            x = self.conv(x)

        return x


class ResBlock(TimestepBlock):
    """
    残差块

    包含两个卷积层和可选的时间/条件嵌入调制
    """

    def __init__(
        self,
        channels: int,
        emb_channels: int,
        dropout: float = 0.0,
        out_channels: int = None,
        use_conv: bool = False,
        use_scale_shift_norm: bool = True,
        dims: int = 2,
        up: bool = False,
        down: bool = False,
    ):
        """
        参数:
            channels: 输入通道数
            emb_channels: 嵌入通道数 (时间嵌入 + 类别嵌入)
            dropout: Dropout 概率
            out_channels: 输出通道数 (默认与输入相同)
            use_conv: 是否使用 3x3 卷积进行跳跃连接
            use_scale_shift_norm: 是否使用 scale-shift 归一化
            dims: 空间维度数
            up: 是否进行上采样
            down: 是否进行下采样
        """
        super().__init__()

        self.channels = channels
        self.emb_channels = emb_channels
        self.dropout = dropout
        self.out_channels = out_channels or channels
        self.use_conv = use_conv
        self.use_scale_shift_norm = use_scale_shift_norm

        # 第一个卷积块
        self.in_layers = nn.Sequential(
            normalization(channels),
            nn.SiLU(),
            conv_nd(dims, channels, self.out_channels, kernel_size=3, padding=1),
        )

        # 上/下采样
        self.updown = up or down
        if up:
            self.h_upd = Upsample(channels, use_conv=False, dims=dims)
            self.x_upd = Upsample(channels, use_conv=False, dims=dims)
        elif down:
            self.h_upd = Downsample(channels, use_conv=False, dims=dims)
            self.x_upd = Downsample(channels, use_conv=False, dims=dims)
        else:
            self.h_upd = self.x_upd = nn.Identity()

        # 嵌入投影
        if use_scale_shift_norm:
            self.emb_layers = nn.Sequential(
                nn.SiLU(),
                nn.Linear(emb_channels, 2 * self.out_channels),
            )
        else:
            self.emb_layers = nn.Sequential(
                nn.SiLU(),
                nn.Linear(emb_channels, self.out_channels),
            )

        # 第二个卷积块
        self.out_layers = nn.Sequential(
            normalization(self.out_channels),
            nn.SiLU(),
            nn.Dropout(p=dropout),
            zero_module(
                conv_nd(dims, self.out_channels, self.out_channels, kernel_size=3, padding=1)
            ),
        )

        # 跳跃连接
        if self.out_channels == channels:
            self.skip_connection = nn.Identity()
        elif use_conv:
            self.skip_connection = conv_nd(
                dims, channels, self.out_channels, kernel_size=3, padding=1
            )
        else:
            self.skip_connection = conv_nd(dims, channels, self.out_channels, kernel_size=1)

    def forward(self, x: torch.Tensor, emb: torch.Tensor) -> torch.Tensor:
        """
        参数:
            x: 输入张量 [batch, channels, ...]
            emb: 嵌入张量 [batch, emb_channels]

        返回:
            输出张量 [batch, out_channels, ...]
        """
        if self.updown:
            # 上/下采样需要在第一个卷积之前处理
            in_rest, in_conv = self.in_layers[:-1], self.in_layers[-1]
            h = in_rest(x)
            h = self.h_upd(h)
            x = self.x_upd(x)
            h = in_conv(h)
        else:
            h = self.in_layers(x)

        # 嵌入调制
        emb_out = self.emb_layers(emb)
        while len(emb_out.shape) < len(h.shape):
            emb_out = emb_out[..., None]

        if self.use_scale_shift_norm:
            # Scale-Shift 归一化
            out_norm, out_rest = self.out_layers[0], self.out_layers[1:]
            scale, shift = torch.chunk(emb_out, 2, dim=1)
            h = out_norm(h) * (1 + scale) + shift
            h = out_rest(h)
        else:
            # 简单加法
            h = h + emb_out
            h = self.out_layers(h)

        # 残差连接
        return self.skip_connection(x) + h


class ResBlockSimple(nn.Module):
    """
    简化版残差块

    不包含时间嵌入调制，用于某些特殊场景
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int = None,
        dropout: float = 0.0,
    ):
        """
        参数:
            in_channels: 输入通道数
            out_channels: 输出通道数
            dropout: Dropout 概率
        """
        super().__init__()

        out_channels = out_channels or in_channels

        self.block1 = nn.Sequential(
            nn.GroupNorm(32, in_channels),
            nn.SiLU(),
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
        )

        self.block2 = nn.Sequential(
            nn.GroupNorm(32, out_channels),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
        )

        if in_channels != out_channels:
            self.shortcut = nn.Conv2d(in_channels, out_channels, kernel_size=1)
        else:
            self.shortcut = nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        参数:
            x: 输入张量 [batch, in_channels, height, width]

        返回:
            输出张量 [batch, out_channels, height, width]
        """
        h = self.block1(x)
        h = self.block2(h)
        return h + self.shortcut(x)


class TimestepEmbedSequential(nn.Sequential, TimestepBlock):
    """
    顺序执行的时间步条件模块

    可以包含普通层和需要时间步嵌入的层
    """

    def forward(self, x: torch.Tensor, emb: torch.Tensor, context: torch.Tensor = None) -> torch.Tensor:
        """
        参数:
            x: 输入张量
            emb: 时间步嵌入
            context: 可选的上下文张量 (用于交叉注意力)

        返回:
            输出张量
        """
        for layer in self:
            if isinstance(layer, TimestepBlock):
                x = layer(x, emb)
            elif hasattr(layer, "forward") and "context" in layer.forward.__code__.co_varnames:
                x = layer(x, context)
            else:
                x = layer(x)
        return x


class ConvBlock(nn.Module):
    """
    标准卷积块

    包含卷积、归一化和激活
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 3,
        stride: int = 1,
        padding: int = 1,
        use_norm: bool = True,
        use_act: bool = True,
    ):
        """
        参数:
            in_channels: 输入通道数
            out_channels: 输出通道数
            kernel_size: 卷积核大小
            stride: 步长
            padding: 填充
            use_norm: 是否使用归一化
            use_act: 是否使用激活函数
        """
        super().__init__()

        layers = [nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding)]

        if use_norm:
            layers.append(nn.GroupNorm(32, out_channels))

        if use_act:
            layers.append(nn.SiLU())

        self.block = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


if __name__ == "__main__":
    # 测试代码
    batch_size = 2
    channels = 128
    emb_channels = 256
    height, width = 32, 32

    print("=" * 50)
    print("测试 UNet 基础块")
    print("=" * 50)

    x = torch.randn(batch_size, channels, height, width)
    emb = torch.randn(batch_size, emb_channels)

    # 测试残差块
    print("\n1. 测试 ResBlock")
    resblock = ResBlock(channels, emb_channels, out_channels=256)
    out = resblock(x, emb)
    print(f"   输入形状: {x.shape}")
    print(f"   输出形状: {out.shape}")

    # 测试下采样
    print("\n2. 测试 Downsample")
    down = Downsample(channels, use_conv=True)
    out = down(x)
    print(f"   输入形状: {x.shape}")
    print(f"   输出形状: {out.shape}")

    # 测试上采样
    print("\n3. 测试 Upsample")
    up = Upsample(channels, use_conv=True)
    out = up(x)
    print(f"   输入形状: {x.shape}")
    print(f"   输出形状: {out.shape}")

    # 测试带上采样的残差块
    print("\n4. 测试 ResBlock with up=True")
    resblock_up = ResBlock(channels, emb_channels, up=True)
    out = resblock_up(x, emb)
    print(f"   输入形状: {x.shape}")
    print(f"   输出形状: {out.shape}")

    # 测试带下采样的残差块
    print("\n5. 测试 ResBlock with down=True")
    resblock_down = ResBlock(channels, emb_channels, down=True)
    out = resblock_down(x, emb)
    print(f"   输入形状: {x.shape}")
    print(f"   输出形状: {out.shape}")

    # 测试简化版残差块
    print("\n6. 测试 ResBlockSimple")
    resblock_simple = ResBlockSimple(channels, 256)
    out = resblock_simple(x)
    print(f"   输入形状: {x.shape}")
    print(f"   输出形状: {out.shape}")

    print("\n测试完成!")
