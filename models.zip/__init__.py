"""
Stanford Dogs Diffusion - 模型模块

包含 UNet 模型及其构建块
"""

from .embeddings import (
    SinusoidalPositionEmbeddings,
    TimeEmbedding,
    ClassEmbedding,
    CombinedEmbedding,
    get_timestep_embedding,
)

from .attention import (
    MultiHeadAttention,
    LinearAttention,
    SpatialSelfAttention,
    CrossAttention,
    AttentionBlock,
    QKVAttention,
)

from .blocks import (
    Downsample,
    Upsample,
    ResBlock,
    ResBlockSimple,
    TimestepBlock,
    TimestepEmbedSequential,
    ConvBlock,
    zero_module,
    normalization,
    conv_nd,
    avg_pool_nd,
)

from .unet import (
    UNetModel,
    UNetModelSmall,
    UNetModelMedium,
    UNetModelLarge,
    get_unet_model,
    count_parameters,
)


__all__ = [
    # Embeddings
    "SinusoidalPositionEmbeddings",
    "TimeEmbedding",
    "ClassEmbedding",
    "CombinedEmbedding",
    "get_timestep_embedding",
    # Attention
    "MultiHeadAttention",
    "LinearAttention",
    "SpatialSelfAttention",
    "CrossAttention",
    "AttentionBlock",
    "QKVAttention",
    # Blocks
    "Downsample",
    "Upsample",
    "ResBlock",
    "ResBlockSimple",
    "TimestepBlock",
    "TimestepEmbedSequential",
    "ConvBlock",
    "zero_module",
    "normalization",
    "conv_nd",
    "avg_pool_nd",
    # UNet
    "UNetModel",
    "UNetModelSmall",
    "UNetModelMedium",
    "UNetModelLarge",
    "get_unet_model",
    "count_parameters",
]
