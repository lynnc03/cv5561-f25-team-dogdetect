"""
UNet 模型 - 用于扩散模型的噪声预测网络

基于 "Denoising Diffusion Probabilistic Models" 论文的 UNet 架构，
包含时间嵌入和可选的类别条件。
"""
from typing import List, Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F

from .embeddings import CombinedEmbedding, TimeEmbedding
from .attention import SpatialSelfAttention, AttentionBlock
from .blocks import (
    ResBlock,
    Downsample,
    Upsample,
    TimestepEmbedSequential,
    zero_module,
    normalization,
    conv_nd,
)


class UNetModel(nn.Module):
    """
    完整的 UNet 模型

    用于扩散模型的噪声预测，支持类别条件生成。

    架构:
    - Encoder: 多个下采样阶段，每个阶段包含残差块和可选的注意力层
    - Middle: 包含残差块和自注意力的瓶颈层
    - Decoder: 多个上采样阶段，带有跳跃连接

    参数说明:
        in_channels: 输入图像通道数 (RGB=3)
        out_channels: 输出通道数 (通常等于 in_channels)
        model_channels: 基础通道数
        num_res_blocks: 每个分辨率阶段的残差块数量
        attention_resolutions: 使用注意力的分辨率列表
        dropout: Dropout 概率
        channel_mult: 各阶段的通道倍数
        num_classes: 类别数量 (用于条件生成)
        use_checkpoint: 是否使用梯度检查点
        num_heads: 注意力头数
        use_scale_shift_norm: 是否使用 scale-shift 归一化
    """

    def __init__(
        self,
        image_size: int = 256,
        in_channels: int = 3,
        out_channels: int = 3,
        model_channels: int = 128,
        num_res_blocks: int = 2,
        attention_resolutions: Tuple[int, ...] = (16, 8),
        dropout: float = 0.1,
        channel_mult: Tuple[int, ...] = (1, 2, 2, 4),
        num_classes: int = None,
        use_checkpoint: bool = False,
        num_heads: int = 8,
        num_head_channels: int = -1,
        use_scale_shift_norm: bool = True,
        resblock_updown: bool = False,
        use_new_attention_order: bool = False,
        class_dropout_prob: float = 0.1,
    ):
        super().__init__()

        self.image_size = image_size
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.model_channels = model_channels
        self.num_res_blocks = num_res_blocks
        self.attention_resolutions = attention_resolutions
        self.dropout = dropout
        self.channel_mult = channel_mult
        self.num_classes = num_classes
        self.use_checkpoint = use_checkpoint
        self.num_heads = num_heads
        self.num_head_channels = num_head_channels
        self.use_scale_shift_norm = use_scale_shift_norm

        # 时间嵌入维度
        time_embed_dim = model_channels * 4

        # 时间嵌入
        self.time_embed = nn.Sequential(
            nn.Linear(model_channels, time_embed_dim),
            nn.SiLU(),
            nn.Linear(time_embed_dim, time_embed_dim),
        )

        # 类别嵌入 (可选)
        if num_classes is not None:
            self.label_emb = nn.Embedding(num_classes, time_embed_dim)
            self.class_dropout_prob = class_dropout_prob
        else:
            self.label_emb = None
            self.class_dropout_prob = 0.0

        # 输入卷积
        self.input_blocks = nn.ModuleList([
            TimestepEmbedSequential(
                conv_nd(2, in_channels, model_channels, 3, padding=1)
            )
        ])

        # 记录各阶段的输出通道数 (用于跳跃连接)
        self._feature_size = model_channels
        input_block_chans = [model_channels]
        ch = model_channels
        ds = 1  # 当前下采样因子

        # 编码器
        for level, mult in enumerate(channel_mult):
            for _ in range(num_res_blocks):
                layers = [
                    ResBlock(
                        ch,
                        time_embed_dim,
                        dropout,
                        out_channels=mult * model_channels,
                        use_scale_shift_norm=use_scale_shift_norm,
                    )
                ]
                ch = mult * model_channels

                # 在特定分辨率添加注意力
                if ds in attention_resolutions:
                    layers.append(
                        AttentionBlock(
                            ch,
                            num_heads=self._get_num_heads(ch),
                            use_linear_attention=False,
                        )
                    )

                self.input_blocks.append(TimestepEmbedSequential(*layers))
                self._feature_size += ch
                input_block_chans.append(ch)

            # 下采样 (除了最后一个阶段)
            if level != len(channel_mult) - 1:
                out_ch = ch
                if resblock_updown:
                    self.input_blocks.append(
                        TimestepEmbedSequential(
                            ResBlock(
                                ch,
                                time_embed_dim,
                                dropout,
                                out_channels=out_ch,
                                use_scale_shift_norm=use_scale_shift_norm,
                                down=True,
                            )
                        )
                    )
                else:
                    self.input_blocks.append(
                        TimestepEmbedSequential(
                            Downsample(ch, use_conv=True, out_channels=out_ch)
                        )
                    )
                ch = out_ch
                input_block_chans.append(ch)
                ds *= 2
                self._feature_size += ch

        # 中间层 (瓶颈)
        self.middle_block = TimestepEmbedSequential(
            ResBlock(
                ch,
                time_embed_dim,
                dropout,
                use_scale_shift_norm=use_scale_shift_norm,
            ),
            AttentionBlock(
                ch,
                num_heads=self._get_num_heads(ch),
            ),
            ResBlock(
                ch,
                time_embed_dim,
                dropout,
                use_scale_shift_norm=use_scale_shift_norm,
            ),
        )
        self._feature_size += ch

        # 解码器
        self.output_blocks = nn.ModuleList([])

        for level, mult in list(enumerate(channel_mult))[::-1]:
            for i in range(num_res_blocks + 1):
                ich = input_block_chans.pop()
                layers = [
                    ResBlock(
                        ch + ich,  # 跳跃连接
                        time_embed_dim,
                        dropout,
                        out_channels=model_channels * mult,
                        use_scale_shift_norm=use_scale_shift_norm,
                    )
                ]
                ch = model_channels * mult

                # 在特定分辨率添加注意力
                if ds in attention_resolutions:
                    layers.append(
                        AttentionBlock(
                            ch,
                            num_heads=self._get_num_heads(ch),
                        )
                    )

                # 上采样
                if level and i == num_res_blocks:
                    out_ch = ch
                    if resblock_updown:
                        layers.append(
                            ResBlock(
                                ch,
                                time_embed_dim,
                                dropout,
                                out_channels=out_ch,
                                use_scale_shift_norm=use_scale_shift_norm,
                                up=True,
                            )
                        )
                    else:
                        layers.append(Upsample(ch, use_conv=True, out_channels=out_ch))
                    ds //= 2

                self.output_blocks.append(TimestepEmbedSequential(*layers))
                self._feature_size += ch

        # 输出层
        self.out = nn.Sequential(
            normalization(ch),
            nn.SiLU(),
            zero_module(conv_nd(2, ch, out_channels, 3, padding=1)),
        )

    def _get_num_heads(self, channels: int) -> int:
        """根据通道数确定注意力头数"""
        if self.num_head_channels > 0:
            return channels // self.num_head_channels
        return self.num_heads

    def timestep_embedding(self, timesteps: torch.Tensor, dim: int, max_period: int = 10000) -> torch.Tensor:
        """
        创建正弦时间步嵌入

        参数:
            timesteps: 时间步张量 [batch_size]
            dim: 嵌入维度
            max_period: 最大周期

        返回:
            嵌入张量 [batch_size, dim]
        """
        half = dim // 2
        freqs = torch.exp(
            -torch.log(torch.tensor(max_period, dtype=torch.float32))
            * torch.arange(start=0, end=half, dtype=torch.float32)
            / half
        ).to(device=timesteps.device)

        args = timesteps[:, None].float() * freqs[None]
        embedding = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)

        if dim % 2:
            embedding = torch.cat([embedding, torch.zeros_like(embedding[:, :1])], dim=-1)

        return embedding

    def forward(
        self,
        x: torch.Tensor,
        timesteps: torch.Tensor,
        y: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        前向传播

        参数:
            x: 输入图像张量 [batch, channels, height, width]
            timesteps: 时间步张量 [batch]
            y: 类别标签 [batch] (可选)

        返回:
            预测的噪声 [batch, channels, height, width]
        """
        # 时间嵌入
        emb = self.timestep_embedding(timesteps, self.model_channels)
        emb = self.time_embed(emb)

        # 添加类别嵌入
        if self.label_emb is not None and y is not None:
            # 训练时随机 drop 类别 (用于 CFG)
            if self.training and self.class_dropout_prob > 0:
                drop_ids = torch.rand(y.shape[0], device=y.device) < self.class_dropout_prob
                # 使用零向量代替 dropped 的类别嵌入
                class_emb = self.label_emb(y)
                class_emb = torch.where(
                    drop_ids[:, None],
                    torch.zeros_like(class_emb),
                    class_emb,
                )
            else:
                class_emb = self.label_emb(y)
            emb = emb + class_emb

        # 编码器
        hs = []
        h = x
        for module in self.input_blocks:
            h = module(h, emb)
            hs.append(h)

        # 中间层
        h = self.middle_block(h, emb)

        # 解码器 (带跳跃连接)
        for module in self.output_blocks:
            h = torch.cat([h, hs.pop()], dim=1)
            h = module(h, emb)

        # 输出
        return self.out(h)

    def forward_with_cfg(
        self,
        x: torch.Tensor,
        timesteps: torch.Tensor,
        y: torch.Tensor,
        cfg_scale: float = 7.5,
    ) -> torch.Tensor:
        """
        使用 Classifier-Free Guidance 的前向传播

        参数:
            x: 输入图像张量
            timesteps: 时间步
            y: 类别标签
            cfg_scale: CFG 强度

        返回:
            引导后的噪声预测
        """
        # 同时计算有条件和无条件的预测
        half = x.shape[0] // 2

        # 有条件预测
        cond_out = self.forward(x[:half], timesteps[:half], y[:half])

        # 无条件预测 (y=None 或使用特殊的 null token)
        uncond_out = self.forward(x[half:], timesteps[half:], None)

        # CFG 公式: output = uncond + cfg_scale * (cond - uncond)
        return uncond_out + cfg_scale * (cond_out - uncond_out)


class UNetModelSmall(UNetModel):
    """
    小型 UNet 模型 (用于快速实验)
    """

    def __init__(
        self,
        image_size: int = 64,
        in_channels: int = 3,
        out_channels: int = 3,
        num_classes: int = None,
        **kwargs,
    ):
        super().__init__(
            image_size=image_size,
            in_channels=in_channels,
            out_channels=out_channels,
            model_channels=64,
            num_res_blocks=2,
            attention_resolutions=(8,),
            dropout=0.1,
            channel_mult=(1, 2, 4),
            num_classes=num_classes,
            num_heads=4,
            **kwargs,
        )


class UNetModelMedium(UNetModel):
    """
    中型 UNet 模型
    """

    def __init__(
        self,
        image_size: int = 128,
        in_channels: int = 3,
        out_channels: int = 3,
        num_classes: int = None,
        **kwargs,
    ):
        super().__init__(
            image_size=image_size,
            in_channels=in_channels,
            out_channels=out_channels,
            model_channels=128,
            num_res_blocks=2,
            attention_resolutions=(16, 8),
            dropout=0.1,
            channel_mult=(1, 2, 2, 4),
            num_classes=num_classes,
            num_heads=8,
            **kwargs,
        )


class UNetModelLarge(UNetModel):
    """
    大型 UNet 模型
    """

    def __init__(
        self,
        image_size: int = 256,
        in_channels: int = 3,
        out_channels: int = 3,
        num_classes: int = None,
        **kwargs,
    ):
        super().__init__(
            image_size=image_size,
            in_channels=in_channels,
            out_channels=out_channels,
            model_channels=192,
            num_res_blocks=3,
            attention_resolutions=(32, 16, 8),
            dropout=0.1,
            channel_mult=(1, 2, 3, 4),
            num_classes=num_classes,
            num_heads=8,
            **kwargs,
        )


def get_unet_model(
    model_size: str = "medium",
    image_size: int = 256,
    num_classes: int = None,
    **kwargs,
) -> UNetModel:
    """
    获取 UNet 模型的工厂函数

    参数:
        model_size: 模型大小 ("small", "medium", "large")
        image_size: 图像大小
        num_classes: 类别数量

    返回:
        UNet 模型实例
    """
    if model_size == "small":
        return UNetModelSmall(image_size=image_size, num_classes=num_classes, **kwargs)
    elif model_size == "medium":
        return UNetModelMedium(image_size=image_size, num_classes=num_classes, **kwargs)
    elif model_size == "large":
        return UNetModelLarge(image_size=image_size, num_classes=num_classes, **kwargs)
    else:
        raise ValueError(f"Unknown model size: {model_size}")


def count_parameters(model: nn.Module) -> int:
    """统计模型参数量"""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


if __name__ == "__main__":
    # 测试代码
    import sys

    print("=" * 60)
    print("UNet 模型测试")
    print("=" * 60)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\n使用设备: {device}")

    # 测试小型模型
    print("\n" + "-" * 40)
    print("1. 测试 UNetModelSmall (64x64)")
    print("-" * 40)

    model_small = UNetModelSmall(image_size=64, num_classes=120).to(device)
    print(f"参数量: {count_parameters(model_small):,}")

    x = torch.randn(2, 3, 64, 64).to(device)
    t = torch.randint(0, 1000, (2,)).to(device)
    y = torch.randint(0, 120, (2,)).to(device)

    with torch.no_grad():
        out = model_small(x, t, y)
    print(f"输入形状: {x.shape}")
    print(f"输出形状: {out.shape}")

    # 测试中型模型
    print("\n" + "-" * 40)
    print("2. 测试 UNetModelMedium (128x128)")
    print("-" * 40)

    model_medium = UNetModelMedium(image_size=128, num_classes=120).to(device)
    print(f"参数量: {count_parameters(model_medium):,}")

    x = torch.randn(2, 3, 128, 128).to(device)
    t = torch.randint(0, 1000, (2,)).to(device)
    y = torch.randint(0, 120, (2,)).to(device)

    with torch.no_grad():
        out = model_medium(x, t, y)
    print(f"输入形状: {x.shape}")
    print(f"输出形状: {out.shape}")

    # 测试大型模型 (如果有足够内存)
    print("\n" + "-" * 40)
    print("3. 测试 UNetModelLarge (256x256)")
    print("-" * 40)

    try:
        model_large = UNetModelLarge(image_size=256, num_classes=120).to(device)
        print(f"参数量: {count_parameters(model_large):,}")

        x = torch.randn(1, 3, 256, 256).to(device)
        t = torch.randint(0, 1000, (1,)).to(device)
        y = torch.randint(0, 120, (1,)).to(device)

        with torch.no_grad():
            out = model_large(x, t, y)
        print(f"输入形状: {x.shape}")
        print(f"输出形状: {out.shape}")
    except RuntimeError as e:
        print(f"内存不足，跳过大型模型测试: {e}")

    # 测试无条件生成
    print("\n" + "-" * 40)
    print("4. 测试无条件生成 (num_classes=None)")
    print("-" * 40)

    model_uncond = UNetModelSmall(image_size=64, num_classes=None).to(device)
    print(f"参数量: {count_parameters(model_uncond):,}")

    x = torch.randn(2, 3, 64, 64).to(device)
    t = torch.randint(0, 1000, (2,)).to(device)

    with torch.no_grad():
        out = model_uncond(x, t, None)
    print(f"输入形状: {x.shape}")
    print(f"输出形状: {out.shape}")

    # 测试工厂函数
    print("\n" + "-" * 40)
    print("5. 测试 get_unet_model 工厂函数")
    print("-" * 40)

    for size in ["small", "medium"]:
        model = get_unet_model(size, image_size=64 if size == "small" else 128, num_classes=120)
        print(f"{size}: {count_parameters(model):,} 参数")

    print("\n" + "=" * 60)
    print("所有测试完成!")
    print("=" * 60)
