"""
时间嵌入和类别嵌入模块
"""
import math
import torch
import torch.nn as nn


class SinusoidalPositionEmbeddings(nn.Module):
    """
    正弦位置嵌入 - 用于编码扩散时间步

    使用正弦和余弦函数将标量时间步映射到高维向量，
    类似于 Transformer 中的位置编码。
    """

    def __init__(self, dim: int, max_period: int = 10000):
        """
        参数:
            dim: 嵌入维度
            max_period: 最大周期 (控制频率范围)
        """
        super().__init__()
        self.dim = dim
        self.max_period = max_period

    def forward(self, timesteps: torch.Tensor) -> torch.Tensor:
        """
        参数:
            timesteps: 时间步张量 [batch_size]

        返回:
            嵌入张量 [batch_size, dim]
        """
        half_dim = self.dim // 2

        # 计算频率
        freqs = torch.exp(
            -math.log(self.max_period) * torch.arange(half_dim, device=timesteps.device) / half_dim
        )

        # 计算角度
        args = timesteps[:, None].float() * freqs[None, :]

        # 正弦和余弦编码
        embedding = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)

        # 如果维度是奇数，补零
        if self.dim % 2:
            embedding = torch.cat([embedding, torch.zeros_like(embedding[:, :1])], dim=-1)

        return embedding


class TimeEmbedding(nn.Module):
    """
    时间嵌入模块

    将时间步通过正弦编码后，再通过 MLP 映射到更高维的特征空间
    """

    def __init__(
        self,
        time_embed_dim: int,
        out_dim: int = None,
        act_fn: str = "silu",
    ):
        """
        参数:
            time_embed_dim: 时间嵌入维度
            out_dim: 输出维度 (默认与 time_embed_dim 相同)
            act_fn: 激活函数 ("silu", "gelu", "relu")
        """
        super().__init__()

        out_dim = out_dim or time_embed_dim

        # 正弦位置编码
        self.sinusoidal_emb = SinusoidalPositionEmbeddings(time_embed_dim)

        # MLP
        self.linear_1 = nn.Linear(time_embed_dim, out_dim)

        if act_fn == "silu":
            self.act = nn.SiLU()
        elif act_fn == "gelu":
            self.act = nn.GELU()
        elif act_fn == "relu":
            self.act = nn.ReLU()
        else:
            raise ValueError(f"Unknown activation function: {act_fn}")

        self.linear_2 = nn.Linear(out_dim, out_dim)

    def forward(self, timesteps: torch.Tensor) -> torch.Tensor:
        """
        参数:
            timesteps: 时间步张量 [batch_size]

        返回:
            时间嵌入 [batch_size, out_dim]
        """
        # 正弦编码
        emb = self.sinusoidal_emb(timesteps)

        # MLP
        emb = self.linear_1(emb)
        emb = self.act(emb)
        emb = self.linear_2(emb)

        return emb


class ClassEmbedding(nn.Module):
    """
    类别嵌入模块

    将离散的类别标签映射到连续的嵌入空间，用于条件生成
    """

    def __init__(
        self,
        num_classes: int,
        embed_dim: int,
        dropout_prob: float = 0.1,
    ):
        """
        参数:
            num_classes: 类别数量
            embed_dim: 嵌入维度
            dropout_prob: Dropout 概率 (用于 Classifier-Free Guidance 训练)
        """
        super().__init__()

        self.num_classes = num_classes
        self.embed_dim = embed_dim
        self.dropout_prob = dropout_prob

        # 类别嵌入表 (+1 用于 null/unconditional token)
        self.embedding = nn.Embedding(num_classes + 1, embed_dim)

        # 可选的投影层
        self.proj = nn.Sequential(
            nn.Linear(embed_dim, embed_dim),
            nn.SiLU(),
            nn.Linear(embed_dim, embed_dim),
        )

    def forward(
        self,
        class_labels: torch.Tensor,
        force_drop_ids: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        参数:
            class_labels: 类别标签 [batch_size]
            force_drop_ids: 强制 drop 的索引 (用于推理时的 CFG)

        返回:
            类别嵌入 [batch_size, embed_dim]
        """
        use_dropout = self.dropout_prob > 0.0

        if self.training and use_dropout:
            # 训练时随机 drop 一些类别 (替换为 null token)
            drop_ids = torch.rand(class_labels.shape[0], device=class_labels.device) < self.dropout_prob
            class_labels = torch.where(drop_ids, self.num_classes, class_labels)

        if force_drop_ids is not None:
            class_labels = torch.where(force_drop_ids, self.num_classes, class_labels)

        # 查找嵌入
        emb = self.embedding(class_labels)

        # 投影
        emb = self.proj(emb)

        return emb


class CombinedEmbedding(nn.Module):
    """
    组合嵌入模块

    将时间嵌入和类别嵌入组合在一起
    """

    def __init__(
        self,
        time_embed_dim: int,
        num_classes: int = None,
        class_embed_dim: int = None,
        class_dropout_prob: float = 0.1,
        use_class_condition: bool = True,
    ):
        """
        参数:
            time_embed_dim: 时间嵌入维度
            num_classes: 类别数量
            class_embed_dim: 类别嵌入维度
            class_dropout_prob: 类别 dropout 概率
            use_class_condition: 是否使用类别条件
        """
        super().__init__()

        self.use_class_condition = use_class_condition

        # 时间嵌入
        self.time_embedding = TimeEmbedding(time_embed_dim, time_embed_dim)

        # 类别嵌入 (可选)
        if use_class_condition and num_classes is not None:
            class_embed_dim = class_embed_dim or time_embed_dim
            self.class_embedding = ClassEmbedding(
                num_classes=num_classes,
                embed_dim=class_embed_dim,
                dropout_prob=class_dropout_prob,
            )

            # 如果维度不同，需要投影
            if class_embed_dim != time_embed_dim:
                self.class_proj = nn.Linear(class_embed_dim, time_embed_dim)
            else:
                self.class_proj = nn.Identity()
        else:
            self.class_embedding = None
            self.class_proj = None

    def forward(
        self,
        timesteps: torch.Tensor,
        class_labels: torch.Tensor = None,
        force_drop_ids: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        参数:
            timesteps: 时间步 [batch_size]
            class_labels: 类别标签 [batch_size] (可选)
            force_drop_ids: 强制 drop 的索引 (可选)

        返回:
            组合嵌入 [batch_size, time_embed_dim]
        """
        # 时间嵌入
        emb = self.time_embedding(timesteps)

        # 添加类别嵌入
        if self.use_class_condition and self.class_embedding is not None and class_labels is not None:
            class_emb = self.class_embedding(class_labels, force_drop_ids)
            class_emb = self.class_proj(class_emb)
            emb = emb + class_emb

        return emb


def get_timestep_embedding(
    timesteps: torch.Tensor,
    embedding_dim: int,
    flip_sin_to_cos: bool = False,
    downscale_freq_shift: float = 1.0,
    scale: float = 1.0,
    max_period: int = 10000,
) -> torch.Tensor:
    """
    独立的时间步嵌入函数 (函数式接口)

    参数:
        timesteps: 时间步张量
        embedding_dim: 嵌入维度
        flip_sin_to_cos: 是否交换 sin 和 cos 的顺序
        downscale_freq_shift: 频率缩放
        scale: 整体缩放因子
        max_period: 最大周期

    返回:
        嵌入张量
    """
    assert len(timesteps.shape) == 1, "Timesteps should be 1D"

    half_dim = embedding_dim // 2
    exponent = -math.log(max_period) * torch.arange(
        start=0, end=half_dim, dtype=torch.float32, device=timesteps.device
    )
    exponent = exponent / (half_dim - downscale_freq_shift)

    emb = timesteps[:, None].float() * torch.exp(exponent)[None, :]
    emb = scale * emb

    # 计算 sin 和 cos
    if flip_sin_to_cos:
        emb = torch.cat([torch.cos(emb), torch.sin(emb)], dim=-1)
    else:
        emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=-1)

    # 处理奇数维度
    if embedding_dim % 2 == 1:
        emb = torch.nn.functional.pad(emb, (0, 1, 0, 0))

    return emb


if __name__ == "__main__":
    # 测试代码
    batch_size = 4
    time_embed_dim = 256
    num_classes = 120

    print("=" * 50)
    print("测试嵌入模块")
    print("=" * 50)

    # 测试时间嵌入
    print("\n1. 测试 TimeEmbedding")
    time_emb = TimeEmbedding(time_embed_dim)
    timesteps = torch.randint(0, 1000, (batch_size,))
    t_emb = time_emb(timesteps)
    print(f"   输入时间步: {timesteps}")
    print(f"   输出形状: {t_emb.shape}")

    # 测试类别嵌入
    print("\n2. 测试 ClassEmbedding")
    class_emb = ClassEmbedding(num_classes, time_embed_dim, dropout_prob=0.1)
    class_labels = torch.randint(0, num_classes, (batch_size,))
    c_emb = class_emb(class_labels)
    print(f"   输入类别: {class_labels}")
    print(f"   输出形状: {c_emb.shape}")

    # 测试组合嵌入
    print("\n3. 测试 CombinedEmbedding")
    combined_emb = CombinedEmbedding(
        time_embed_dim=time_embed_dim,
        num_classes=num_classes,
        use_class_condition=True,
    )
    emb = combined_emb(timesteps, class_labels)
    print(f"   输出形状: {emb.shape}")

    # 测试函数式接口
    print("\n4. 测试 get_timestep_embedding")
    func_emb = get_timestep_embedding(timesteps, time_embed_dim)
    print(f"   输出形状: {func_emb.shape}")

    print("\n测试完成!")
