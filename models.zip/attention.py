"""
注意力机制模块
"""
import math
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange


class MultiHeadAttention(nn.Module):
    """
    多头自注意力机制

    用于捕获图像特征图中的长距离依赖关系
    """

    def __init__(
        self,
        dim: int,
        num_heads: int = 8,
        head_dim: int = None,
        dropout: float = 0.0,
        bias: bool = True,
    ):
        """
        参数:
            dim: 输入维度
            num_heads: 注意力头数
            head_dim: 每个头的维度 (默认为 dim // num_heads)
            dropout: Dropout 概率
            bias: 是否使用偏置
        """
        super().__init__()

        self.num_heads = num_heads
        self.head_dim = head_dim or dim // num_heads
        self.inner_dim = self.num_heads * self.head_dim
        self.scale = self.head_dim ** -0.5

        # QKV 投影
        self.to_qkv = nn.Linear(dim, self.inner_dim * 3, bias=bias)

        # 输出投影
        self.to_out = nn.Sequential(
            nn.Linear(self.inner_dim, dim, bias=bias),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor, mask: torch.Tensor = None) -> torch.Tensor:
        """
        参数:
            x: 输入张量 [batch, seq_len, dim]
            mask: 注意力掩码 (可选)

        返回:
            输出张量 [batch, seq_len, dim]
        """
        b, n, _ = x.shape

        # 计算 Q, K, V
        qkv = self.to_qkv(x)
        qkv = rearrange(qkv, "b n (three h d) -> three b h n d", three=3, h=self.num_heads)
        q, k, v = qkv[0], qkv[1], qkv[2]

        # 缩放点积注意力
        attn = torch.matmul(q, k.transpose(-1, -2)) * self.scale

        if mask is not None:
            attn = attn.masked_fill(mask == 0, float("-inf"))

        attn = F.softmax(attn, dim=-1)

        # 加权求和
        out = torch.matmul(attn, v)
        out = rearrange(out, "b h n d -> b n (h d)")

        return self.to_out(out)


class LinearAttention(nn.Module):
    """
    线性注意力机制

    计算复杂度为 O(n) 而非 O(n^2)，适用于高分辨率特征图
    """

    def __init__(
        self,
        dim: int,
        num_heads: int = 4,
        head_dim: int = 32,
    ):
        """
        参数:
            dim: 输入维度
            num_heads: 注意力头数
            head_dim: 每个头的维度
        """
        super().__init__()

        self.num_heads = num_heads
        self.head_dim = head_dim
        self.inner_dim = num_heads * head_dim
        self.scale = head_dim ** -0.5

        self.to_qkv = nn.Conv2d(dim, self.inner_dim * 3, 1, bias=False)
        self.to_out = nn.Sequential(
            nn.Conv2d(self.inner_dim, dim, 1),
            nn.GroupNorm(1, dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        参数:
            x: 输入张量 [batch, channels, height, width]

        返回:
            输出张量 [batch, channels, height, width]
        """
        b, c, h, w = x.shape

        qkv = self.to_qkv(x)
        q, k, v = qkv.chunk(3, dim=1)

        q = rearrange(q, "b (h d) x y -> b h (x y) d", h=self.num_heads)
        k = rearrange(k, "b (h d) x y -> b h (x y) d", h=self.num_heads)
        v = rearrange(v, "b (h d) x y -> b h (x y) d", h=self.num_heads)

        # 使用 softmax 近似
        q = q.softmax(dim=-1)
        k = k.softmax(dim=-2)

        q = q * self.scale

        # 线性注意力: (Q @ K^T) @ V = Q @ (K^T @ V)
        context = torch.einsum("b h n d, b h n e -> b h d e", k, v)
        out = torch.einsum("b h n d, b h d e -> b h n e", q, context)

        out = rearrange(out, "b h (x y) d -> b (h d) x y", x=h, y=w)

        return self.to_out(out)


class SpatialSelfAttention(nn.Module):
    """
    空间自注意力模块

    用于 UNet 中间层，在空间维度上计算自注意力
    """

    def __init__(
        self,
        channels: int,
        num_heads: int = 8,
        head_dim: int = None,
        dropout: float = 0.0,
    ):
        """
        参数:
            channels: 输入通道数
            num_heads: 注意力头数
            head_dim: 每个头的维度
            dropout: Dropout 概率
        """
        super().__init__()

        self.channels = channels
        self.num_heads = num_heads
        self.head_dim = head_dim or channels // num_heads

        # 归一化
        self.norm = nn.GroupNorm(32, channels)

        # 注意力
        self.attention = MultiHeadAttention(
            dim=channels,
            num_heads=num_heads,
            head_dim=self.head_dim,
            dropout=dropout,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        参数:
            x: 输入张量 [batch, channels, height, width]

        返回:
            输出张量 [batch, channels, height, width]
        """
        b, c, h, w = x.shape

        # 归一化
        x_norm = self.norm(x)

        # 重塑为序列
        x_flat = rearrange(x_norm, "b c h w -> b (h w) c")

        # 注意力
        attn_out = self.attention(x_flat)

        # 重塑回空间维度
        attn_out = rearrange(attn_out, "b (h w) c -> b c h w", h=h, w=w)

        # 残差连接
        return x + attn_out


class CrossAttention(nn.Module):
    """
    交叉注意力模块

    用于将条件信息（如类别嵌入）注入到图像特征中
    """

    def __init__(
        self,
        query_dim: int,
        context_dim: int = None,
        num_heads: int = 8,
        head_dim: int = 64,
        dropout: float = 0.0,
    ):
        """
        参数:
            query_dim: 查询维度
            context_dim: 上下文维度 (如果为 None，则等于 query_dim，变成自注意力)
            num_heads: 注意力头数
            head_dim: 每个头的维度
            dropout: Dropout 概率
        """
        super().__init__()

        context_dim = context_dim or query_dim

        self.num_heads = num_heads
        self.head_dim = head_dim
        self.inner_dim = num_heads * head_dim
        self.scale = head_dim ** -0.5

        # Q 从输入计算
        self.to_q = nn.Linear(query_dim, self.inner_dim, bias=False)

        # K, V 从上下文计算
        self.to_k = nn.Linear(context_dim, self.inner_dim, bias=False)
        self.to_v = nn.Linear(context_dim, self.inner_dim, bias=False)

        # 输出投影
        self.to_out = nn.Sequential(
            nn.Linear(self.inner_dim, query_dim),
            nn.Dropout(dropout),
        )

    def forward(
        self,
        x: torch.Tensor,
        context: torch.Tensor = None,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        参数:
            x: 查询张量 [batch, seq_len, query_dim]
            context: 上下文张量 [batch, context_len, context_dim]
            mask: 注意力掩码

        返回:
            输出张量 [batch, seq_len, query_dim]
        """
        if context is None:
            context = x

        b, n, _ = x.shape

        q = self.to_q(x)
        k = self.to_k(context)
        v = self.to_v(context)

        # 重塑为多头
        q = rearrange(q, "b n (h d) -> b h n d", h=self.num_heads)
        k = rearrange(k, "b m (h d) -> b h m d", h=self.num_heads)
        v = rearrange(v, "b m (h d) -> b h m d", h=self.num_heads)

        # 注意力分数
        attn = torch.matmul(q, k.transpose(-1, -2)) * self.scale

        if mask is not None:
            attn = attn.masked_fill(mask == 0, float("-inf"))

        attn = F.softmax(attn, dim=-1)

        # 加权求和
        out = torch.matmul(attn, v)
        out = rearrange(out, "b h n d -> b n (h d)")

        return self.to_out(out)


class AttentionBlock(nn.Module):
    """
    注意力块

    包含自注意力和前馈网络，类似于 Transformer 块
    """

    def __init__(
        self,
        dim: int,
        num_heads: int = 8,
        head_dim: int = None,
        dropout: float = 0.0,
        context_dim: int = None,
        use_linear_attention: bool = False,
    ):
        """
        参数:
            dim: 输入维度
            num_heads: 注意力头数
            head_dim: 每个头的维度
            dropout: Dropout 概率
            context_dim: 交叉注意力的上下文维度
            use_linear_attention: 是否使用线性注意力
        """
        super().__init__()

        # 归一化层
        self.norm1 = nn.GroupNorm(32, dim)
        self.norm2 = nn.GroupNorm(32, dim)

        # 自注意力
        if use_linear_attention:
            self.attn = LinearAttention(dim, num_heads)
        else:
            self.attn = SpatialSelfAttention(
                channels=dim,
                num_heads=num_heads,
                head_dim=head_dim,
                dropout=dropout,
            )

        # 交叉注意力 (可选)
        self.cross_attn = None
        if context_dim is not None:
            self.norm_cross = nn.GroupNorm(32, dim)
            self.cross_attn = CrossAttention(
                query_dim=dim,
                context_dim=context_dim,
                num_heads=num_heads,
                head_dim=head_dim or dim // num_heads,
                dropout=dropout,
            )

        # 前馈网络
        self.ff = nn.Sequential(
            nn.GroupNorm(32, dim),
            nn.Conv2d(dim, dim * 4, 1),
            nn.GELU(),
            nn.Conv2d(dim * 4, dim, 1),
            nn.Dropout(dropout),
        )

    def forward(
        self,
        x: torch.Tensor,
        context: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        参数:
            x: 输入张量 [batch, channels, height, width]
            context: 上下文张量 [batch, context_len, context_dim] (可选)

        返回:
            输出张量 [batch, channels, height, width]
        """
        # 自注意力
        x = self.attn(self.norm1(x)) + x

        # 交叉注意力
        if self.cross_attn is not None and context is not None:
            b, c, h, w = x.shape
            x_flat = rearrange(self.norm_cross(x), "b c h w -> b (h w) c")
            x_flat = self.cross_attn(x_flat, context)
            x = rearrange(x_flat, "b (h w) c -> b c h w", h=h, w=w) + x

        # 前馈网络
        x = self.ff(x) + x

        return x


class QKVAttention(nn.Module):
    """
    QKV 注意力

    用于 UNet 中的注意力层，直接在通道维度操作
    """

    def __init__(self, num_heads: int):
        super().__init__()
        self.num_heads = num_heads

    def forward(self, qkv: torch.Tensor) -> torch.Tensor:
        """
        参数:
            qkv: [batch, (3 * num_heads * head_dim), height * width]

        返回:
            输出张量 [batch, (num_heads * head_dim), height * width]
        """
        bs, width, length = qkv.shape
        assert width % (3 * self.num_heads) == 0
        ch = width // (3 * self.num_heads)

        q, k, v = qkv.chunk(3, dim=1)
        scale = 1 / math.sqrt(math.sqrt(ch))

        weight = torch.einsum(
            "bct,bcs->bts",
            (q * scale).view(bs * self.num_heads, ch, length),
            (k * scale).view(bs * self.num_heads, ch, length),
        )

        weight = torch.softmax(weight.float(), dim=-1).type(weight.dtype)

        a = torch.einsum(
            "bts,bcs->bct",
            weight,
            v.view(bs * self.num_heads, ch, length),
        )

        return a.view(bs, -1, length)


if __name__ == "__main__":
    # 测试代码
    batch_size = 2
    channels = 256
    height, width = 16, 16
    num_heads = 8

    print("=" * 50)
    print("测试注意力模块")
    print("=" * 50)

    x = torch.randn(batch_size, channels, height, width)

    # 测试空间自注意力
    print("\n1. 测试 SpatialSelfAttention")
    spatial_attn = SpatialSelfAttention(channels, num_heads)
    out = spatial_attn(x)
    print(f"   输入形状: {x.shape}")
    print(f"   输出形状: {out.shape}")

    # 测试线性注意力
    print("\n2. 测试 LinearAttention")
    linear_attn = LinearAttention(channels, num_heads=4, head_dim=32)
    out = linear_attn(x)
    print(f"   输出形状: {out.shape}")

    # 测试注意力块
    print("\n3. 测试 AttentionBlock")
    attn_block = AttentionBlock(channels, num_heads, context_dim=512)
    context = torch.randn(batch_size, 10, 512)
    out = attn_block(x, context)
    print(f"   输出形状: {out.shape}")

    # 测试多头注意力
    print("\n4. 测试 MultiHeadAttention")
    seq_len = 64
    dim = 256
    x_seq = torch.randn(batch_size, seq_len, dim)
    mha = MultiHeadAttention(dim, num_heads)
    out = mha(x_seq)
    print(f"   输入形状: {x_seq.shape}")
    print(f"   输出形状: {out.shape}")

    print("\n测试完成!")
